-- Set lock timeout so that lock waittime rolls up to sys.dm_os_wait_stats before the 
-- end of the blocking incident
SET LOCK_TIMEOUT 17890
GO

-- Sleep a random amount of time (0-5 sec) so that all blocked spids don't 
-- sleep and wake in artificial-looking lockstep
DECLARE @waittime varchar(30)
SET @waittime = '0:0:0.' + CONVERT (varchar, CONVERT (decimal (3,2), RAND()*5))
WAITFOR DELAY @waittime

GO
SELECT DISTINCT JobTitle 
FROM HumanResources.Employee 
ORDER BY JobTitle;
GO
