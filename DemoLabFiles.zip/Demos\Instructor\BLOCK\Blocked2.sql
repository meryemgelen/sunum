-- Set lock timeout so that lock waittime rolls up to sys.dm_os_wait_stats before the
-- end of the blocking incident
SET LOCK_TIMEOUT 17890
GO

-- Sleep a random amount of time (0-10 sec) so that all blocked spids don't 
-- have the exact same waittime once blocked
DECLARE @waittime varchar(30)
SET @waittime = '0:0:' + CONVERT (varchar, CONVERT (decimal (3,2), RAND()*5))
WAITFOR DELAY @waittime

GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
DECLARE @rnd int
SET @rnd = RAND() * 10000
EXEC sp_executesql N'SELECT DueDate FROM Sales.SalesOrderHeader WHERE ContactID = @P1', N'@P1 int', @P1 = @rnd
GO
