-- Simulate an app that has lost track of its transaction nesting level
USE AdventureWorksPTO
GO
BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO

SELECT DISTINCT JobTitle 
FROM HumanResources.Employee 
ORDER BY JobTitle ;

GO
!!..\bin\sleep 10
GO

BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO

SELECT DISTINCT JobTitle 
FROM HumanResources.Employee 
ORDER BY JobTitle ;

GO
!!..\bin\sleep 10
GO

GO
::r ..\common\BackgroundWorkload.sql
GO

BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO

BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO

SELECT DISTINCT JobTitle 
FROM HumanResources.Employee 
ORDER BY JobTitle ;

GO
!!..\bin\sleep 10
GO

BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO

SELECT DISTINCT JobTitle 
FROM HumanResources.Employee 
ORDER BY JobTitle ;

GO
!!..\bin\sleep 10
GO

GO
::r ..\common\BackgroundWorkload.sql
GO

BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO

BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO

GO
::r ..\common\BackgroundWorkload.sql
GO
!!..\bin\sleep 10
GO
::r ..\common\BackgroundWorkload.sql
GO
!!..\bin\sleep 10
GO
BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO
::r ..\common\BackgroundWorkload.sql
GO
!!..\bin\sleep 10
GO
::r ..\common\BackgroundWorkload.sql
GO
BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO
!!..\bin\sleep 10
GO
::r ..\common\BackgroundWorkload.sql
GO
!!..\bin\sleep 10
GO
BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO
::r ..\common\BackgroundWorkload.sql
GO
!!..\bin\sleep 10
GO
::r ..\common\BackgroundWorkload.sql
GO
!!..\bin\sleep 10
GO
::r ..\common\BackgroundWorkload.sql
GO
!!..\bin\sleep 10
GO
::r ..\common\BackgroundWorkload.sql
GO
!!..\bin\sleep 10
GO
BEGIN TRAN
UPDATE HumanResources.Employee SET BirthDate = DATEADD (d, 1, BirthDate)
GO
::r ..\common\BackgroundWorkload.sql
GO
!!..\bin\sleep 600
GO
