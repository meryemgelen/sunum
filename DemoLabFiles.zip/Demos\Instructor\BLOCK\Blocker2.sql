USE AdventureWorksPTO
GO
SET IMPLICIT_TRANSACTIONS ON
GO

UPDATE Sales.SalesOrderHeader SET DueDate = DATEADD (d, 5, DueDate)
GO

SELECT sh.SalesOrderID AS [Order], nextorder_sh.SalesOrderID AS NextOrder,  
	SUM (nextorder_sd.LineTotal) - SUM (sd.LineTotal) AS Trend, 
	(SELECT AVG (TotalDue) FROM Sales.SalesOrderHeader AS sh3 WHERE sh3.AccountNumber = nextorder_sh.AccountNumber)
		AS acct_avg
FROM Sales.SalesOrderDetail AS sd
INNER JOIN Sales.SalesOrderHeader AS sh ON sd.SalesOrderID = sh.SalesOrderID
INNER JOIN Sales.SalesOrderHeader AS nextorder_sh ON sh.AccountNumber = nextorder_sh.AccountNumber 
	AND nextorder_sh.SalesOrderID = (
		SELECT TOP 1 sh2.SalesOrderID FROM Sales.SalesOrderHeader AS sh2
		WHERE sh2.AccountNumber = nextorder_sh.AccountNumber AND sh2.OrderDate > sh.OrderDate
		ORDER BY sh2.OrderDate
	)
INNER JOIN Sales.SalesOrderDetail AS nextorder_sd ON nextorder_sd.SalesOrderID = nextorder_sh.SalesOrderID
GROUP BY nextorder_sh.AccountNumber, sh.SalesOrderID, nextorder_sh.SalesOrderID
OPTION (LOOP JOIN, FORCE ORDER)
GO
