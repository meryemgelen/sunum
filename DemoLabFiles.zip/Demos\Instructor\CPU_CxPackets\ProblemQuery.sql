USE AdventureWorksPTO
SET NOCOUNT ON
GO

EXEC sp_executesql N'SELECT ProductID
    FROM Sales.SalesOrderDetail2
    WHERE UnitPrice < 25.00
    GROUP BY ProductID
    HAVING AVG(OrderQty) > @P1
    ORDER BY ProductID', 
    N'@P1 int', @P1 = 5
GO
!!..\bin\sleep 1
GO

DECLARE @x int
DECLARE @rnd int
SET @x = 1
WHILE @x < 30
BEGIN
    SET @rnd = (RAND() * 6) * 5
    EXEC sp_executesql N'SELECT ProductID
        FROM Sales.SalesOrderDetail2  
        WHERE UnitPrice < 25.00
        GROUP BY ProductID
        HAVING AVG(OrderQty) > @P1
        ORDER BY ProductID', 
        N'@P1 int', @P1 = @rnd
    SET @x = @x + 1
END
GO
!!..\bin\sleep 1
GO

DECLARE @x int
DECLARE @rnd int
SET @x = 1
WHILE @x < 30
BEGIN
    SET @rnd = (RAND() * 6) * 5
    EXEC sp_executesql N'
        SELECT ProductID
        FROM Sales.SalesOrderDetail2  
        WHERE UnitPrice < 25.00
        GROUP BY ProductID
        HAVING AVG(OrderQty) > @P1
        ORDER BY ProductID', 
        N'@P1 int', @P1 = @rnd
    SET @x = @x + 1
END
GO
!!..\bin\sleep 1
GO

DECLARE @x int
DECLARE @rnd int
SET @x = 1
WHILE @x < 30
BEGIN
    SET @rnd = (RAND() * 6) * 5
    EXEC sp_executesql N'
        SELECT ProductID
        FROM Sales.SalesOrderDetail2  
        WHERE UnitPrice < 25.00
        GROUP BY ProductID
        HAVING AVG(OrderQty) > @P1
        ORDER BY ProductID', 
        N'@P1 int', @P1 = @rnd
    SET @x = @x + 1
END
GO
!!..\bin\sleep 1
GO

DECLARE @x int
DECLARE @rnd int
SET @x = 1
WHILE @x < 30
BEGIN
    SET @rnd = (RAND() * 6) * 5
    EXEC sp_executesql N'
        SELECT ProductID
        FROM Sales.SalesOrderDetail2  
        WHERE UnitPrice < 25.00
        GROUP BY ProductID
        HAVING AVG(OrderQty) > @P1
        ORDER BY ProductID', 
        N'@P1 int', @P1 = @rnd
    SET @x = @x + 1
END
GO
!!..\bin\sleep 1
GO

DECLARE @x int
DECLARE @rnd int
SET @x = 1
WHILE @x < 30
BEGIN
    SET @rnd = (RAND() * 6) * 5
    EXEC sp_executesql N'
        SELECT ProductID
        FROM Sales.SalesOrderDetail2  
        WHERE UnitPrice < 25.00
        GROUP BY ProductID
        HAVING AVG(OrderQty) > @P1
        ORDER BY ProductID', 
        N'@P1 int', @P1 = @rnd
    SET @x = @x + 1
END
GO
!!..\bin\sleep 1
GO

DECLARE @x int
DECLARE @rnd int
SET @x = 1
WHILE @x < 30
BEGIN
	SELECT SOD.SalesOrderID, SOD.SalesOrderDetailID, SOD.CarrierTrackingNumber, SOD.OrderQty, SOD.ProductID, SOD.UnitPrice, SOD.UnitPriceDiscount, SOD.LineTotal, P.Name, P.StandardCost, P.ListPrice, P.Color
	FROM Sales.SalesOrderDetail2 AS SOD 
	INNER JOIN Production.Product AS P ON SOD.ProductID = P.ProductID
	ORDER BY P.Style
    SET @x = @x + 1
END
GO
!!..\bin\sleep 1
GO
