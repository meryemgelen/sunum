USE AdventureWorksPTO
SET NOCOUNT ON
GO

EXEC sp_executesql N'SELECT ProductID
    FROM Sales.SalesOrderDetail2 
    WHERE UnitPrice < 25.00
    GROUP BY ProductID
    HAVING AVG(OrderQty) > @P1
    ORDER BY ProductID', 
    N'@P1 int', @P1 = 5
GO
!!..\bin\sleep 1
GO

DECLARE @x int
DECLARE @rnd int
SET @x = 1
WHILE @x < 10
BEGIN
    SET @rnd = (RAND() * 6) * 5
    EXEC sp_executesql N'SELECT ProductID
        FROM Sales.SalesOrderDetail2  
        WHERE UnitPrice < 25.00
        GROUP BY ProductID
        HAVING AVG(OrderQty) > @P1
        ORDER BY ProductID', 
        N'@P1 int', @P1 = @rnd

	EXEC sp_executesql N'SELECT s.OrderDate, s.DueDate, s.ShipDate, s.Status, s.OnlineOrderFlag, s.SalesOrderNumber, s.PurchaseOrderNumber, s.AccountNumber, s.CustomerID, 
	s.SalesPersonID, s.CurrencyRateID, s.SubTotal, s.TaxAmt, s.Freight, s.TotalDue, s.Comment, d.CarrierTrackingNumber, d.OrderQty, d.UnitPrice, 
	d.UnitPriceDiscount, d.LineTotal
	FROM Sales.SalesOrderHeader AS s 
	INNER JOIN Sales.SalesOrderDetail2 AS d ON s.SalesOrderID = d.SalesOrderID
	WHERE s.TotalDue > 117.00 + 1000.00 + @x', 
    N'@P1 int', @P1 = @x
	
	EXEC sp_executesql N'SELECT TOP 10000 *
	FROM Sales.SalesOrderHeader SOH, Sales.SalesOrderDetail2 SOD, Production.Product P
	WHERE SOH.SalesOrderID = 43659 + @x', 
    N'@P1 int', @P1 = @x
	
	SELECT TOP (1000) SalesOrderID, CarrierTrackingNumber, OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount, LineTotal, rowguid, ModifiedDate, ROW_NUMBER() OVER (PARTITION BY OrderQty ORDER BY ProductId) AS [row] 
	FROM Sales.SalesOrderDetail2
	--ORDER BY SalesOrderID DESC
	
    SET @x = @x + 1
END
GO
!!..\bin\sleep 1
GO

SET @x = 1
WHILE @x < 2
BEGIN

	EXEC sp_executesql N'SELECT SOD.SalesOrderID, SOD.SalesOrderDetailID, SOD.CarrierTrackingNumber, SOD.OrderQty, SOD.ProductID, SOD.UnitPrice, SOD.UnitPriceDiscount, SOD.LineTotal, P.Name, P.StandardCost, P.ListPrice, P.Color
	FROM Sales.SalesOrderDetail2 AS SOD 
	INNER JOIN Production.Product AS P ON SOD.ProductID = P.ProductID
	ORDER BY P.Style'
    SET @x = @x + 1
END
GO
!!..\bin\sleep 1
GO
