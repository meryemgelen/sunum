USE [AdventureWorksPTO]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderDetail2]') AND type in (N'U'))
DROP TABLE [Sales].[SalesOrderDetail2]
GO
*/

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderDetail2]') AND type in (N'U'))
BEGIN
	CREATE TABLE [Sales].[SalesOrderDetail2](
		[SalesOrderID] [int] NOT NULL,
		[SalesOrderDetailID] [int] IDENTITY(1,1) NOT NULL,
		[CarrierTrackingNumber] [nvarchar](25) NULL,
		[OrderQty] [smallint] NOT NULL,
		[ProductID] [int] NOT NULL,
		[SpecialOfferID] [int] NOT NULL,
		[UnitPrice] [money] NOT NULL,
		[UnitPriceDiscount] [money] NOT NULL,
		[LineTotal]  AS (isnull(([UnitPrice]*((1.0)-[UnitPriceDiscount]))*[OrderQty],(0.0))),
		[rowguid] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
		[ModifiedDate] [datetime] NOT NULL,
	 CONSTRAINT [PK_SalesOrderDetail2_SalesOrderID_SalesOrderDetailID] PRIMARY KEY CLUSTERED 
	(
		[SalesOrderID] ASC,
		[SalesOrderDetailID] ASC
	)WITH (ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	);

	ALTER TABLE [Sales].[SalesOrderDetail2] ADD  CONSTRAINT [DF_SalesOrderDetail2_UnitPriceDiscount]  DEFAULT ((0.0)) FOR [UnitPriceDiscount]
	ALTER TABLE [Sales].[SalesOrderDetail2] ADD  CONSTRAINT [DF_SalesOrderDetail2_rowguid]  DEFAULT (newid()) FOR [rowguid]
	ALTER TABLE [Sales].[SalesOrderDetail2] ADD  CONSTRAINT [DF_SalesOrderDetail2_ModifiedDate]  DEFAULT (getdate()) FOR [ModifiedDate]
	ALTER TABLE [Sales].[SalesOrderDetail2]  WITH CHECK ADD  CONSTRAINT [FK_SalesOrderDetail2_SalesOrderHeader_SalesOrderID] FOREIGN KEY([SalesOrderID])
	REFERENCES [Sales].[SalesOrderHeader] ([SalesOrderID])
	ALTER TABLE [Sales].[SalesOrderDetail2] CHECK CONSTRAINT [FK_SalesOrderDetail2_SalesOrderHeader_SalesOrderID]
	ALTER TABLE [Sales].[SalesOrderDetail2]  WITH CHECK ADD  CONSTRAINT [FK_SalesOrderDetail2_SpecialOfferProduct_SpecialOfferIDProductID] FOREIGN KEY([SpecialOfferID], [ProductID])
	REFERENCES [Sales].[SpecialOfferProduct] ([SpecialOfferID], [ProductID])
	ALTER TABLE [Sales].[SalesOrderDetail2] CHECK CONSTRAINT [FK_SalesOrderDetail2_SpecialOfferProduct_SpecialOfferIDProductID]
	ALTER TABLE [Sales].[SalesOrderDetail2]  WITH CHECK ADD  CONSTRAINT [CK_SalesOrderDetail2_OrderQty] CHECK  (([OrderQty]>(0)))
	ALTER TABLE [Sales].[SalesOrderDetail2] CHECK CONSTRAINT [CK_SalesOrderDetail2_OrderQty]
	ALTER TABLE [Sales].[SalesOrderDetail2]  WITH CHECK ADD  CONSTRAINT [CK_SalesOrderDetail2_UnitPrice] CHECK  (([UnitPrice]>=(0.00)))
	ALTER TABLE [Sales].[SalesOrderDetail2] CHECK CONSTRAINT [CK_SalesOrderDetail2_UnitPrice]
	ALTER TABLE [Sales].[SalesOrderDetail2]  WITH CHECK ADD  CONSTRAINT [CK_SalesOrderDetail2_UnitPriceDiscount] CHECK  (([UnitPriceDiscount]>=(0.00)))
	ALTER TABLE [Sales].[SalesOrderDetail2] CHECK CONSTRAINT [CK_SalesOrderDetail2_UnitPriceDiscount]
END
GO

DECLARE @cnt tinyint
SET @cnt = 0
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderDetail2]') AND type in (N'U'))
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM [Sales].[SalesOrderDetail2])
	BEGIN
		WHILE @cnt <> 3
		BEGIN
			INSERT INTO [Sales].[SalesOrderDetail2]
			SELECT [SalesOrderID]
				,[CarrierTrackingNumber]
				,[OrderQty]
				,[ProductID]
				,[SpecialOfferID]
				,[UnitPrice]
				,[UnitPriceDiscount]
				,[rowguid]
				,[ModifiedDate]
			FROM [Sales].[SalesOrderDetail]
			SET @cnt = @cnt + 1
		END
	END
END
GO

IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderDetail2]') AND name = 'IX1')
DROP INDEX Sales.SalesOrderDetail2.IX1
GO
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderDetail2]') AND name = 'IX2')
DROP INDEX Sales.SalesOrderDetail2.IX2
GO
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'Production.Product') AND name = 'IX1')
DROP INDEX Production.Product.IX1
GO
IF EXISTS (SELECT * FROM sys.stats WHERE object_id = OBJECT_ID(N'Production.Product') AND name = 'Stat_1')
DROP STATISTICS Production.Product.Stat_1
GO
