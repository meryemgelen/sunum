USE AdventureWorksPTO
GO
DROP TABLE tblThreadPool;
GO
DROP PROCEDURE uspReadWorkload;
GO
