USE AdventureWorksPTO
SET NOCOUNT ON
GO

-- Begin a transaction that never commits...
BEGIN TRANSACTION
	UPDATE dbo.tblThreadPool SET c2 = 2 WHERE c1 = 1
GO

!!..\bin\sleep 1
GO
