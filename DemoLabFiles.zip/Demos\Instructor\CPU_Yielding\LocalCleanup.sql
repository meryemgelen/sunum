USE AdventureWorksPTO
GO
DROP TABLE SampleTable;
GO
