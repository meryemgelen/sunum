USE AdventureWorksPTO
SET NOCOUNT ON
GO

DECLARE @a int, @b int, @c int
WHILE (1=1)
BEGIN 
	SELECT @a = COUNT (*) FROM SampleTable WHERE c1 = 1;
	SELECT @b = COUNT (*) FROM SampleTable WHERE c1 = 2;
	SELECT @c = COUNT (*) FROM SampleTable WHERE c1 = 3;
	SELECT @a + @b + @c
END;
GO

!!..\bin\sleep 1
GO
