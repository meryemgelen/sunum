SET NOCOUNT ON
DECLARE @i int=0
WHILE (@i<1000)
BEGIN
	INSERT INTO dbo.HeavyInsert (col1) VALUES ('testing heavy')
	SET @i+=1
END