USE AdventureWorksPTO
GO
SET STATISTICS IO ON
WHILE (1=1) 
BEGIN
    DBCC DROPCLEANBUFFERS;
    SELECT COUNT(DISTINCT d.LineTotal) 
    FROM Sales.SalesOrderHeader AS h
    INNER JOIN Sales.SalesOrderDetail AS d ON h.SalesOrderID = d.SalesOrderID
    INNER JOIN Sales.Customer AS i ON h.CustomerID = i.CustomerID
    WHERE h.TerritoryID > 0 AND d.LineTotal > 0 AND i.TerritoryID > 0
    OPTION (HASH JOIN, MAXDOP 1)
END
GO
