-- Select from all tables in AdventureWorksDW2016
USE [AdventureWorksDWPTO]
GO
BEGIN TRAN
SELECT * FROM [dbo].[DimAccount] 
--GO
SELECT * FROM [dbo].[DimCurrency] 
--GO
SELECT * FROM [dbo].[DimCustomer] 
--GO
SELECT * FROM [dbo].[DimDate] 
--GO
SELECT * FROM [dbo].[DimDepartmentGroup] 
--GO
SELECT * FROM [dbo].[DimEmployee] 
--GO
SELECT * FROM [dbo].[DimGeography] 
--GO
SELECT * FROM [dbo].[DimOrganization] 
--GO
SELECT * FROM [dbo].[DimProduct] 
--GO
SELECT * FROM [dbo].[DimProductCategory] 
--GO
SELECT * FROM [dbo].[DimProductSubcategory] 
--GO
SELECT * FROM [dbo].[DimPromotion] 
--GO
SELECT * FROM [dbo].[DimReseller] 
--GO
SELECT * FROM [dbo].[DimSalesReason] 
--GO
SELECT * FROM [dbo].[DimSalesTerritory] 
--GO
SELECT * FROM [dbo].[DimScenario] 
--GO
SELECT * FROM [dbo].[FactCallCenter] 
--GO
SELECT * FROM [dbo].[FactCurrencyRate] 
--GO
SELECT * FROM [dbo].[FactFinance] 
--GO
SELECT * FROM [dbo].[FactInternetSales] 
--GO
SELECT * FROM [dbo].[FactResellerSales] 
--GO
SELECT * FROM [dbo].[FactInternetSalesReason] 
--GO
SELECT * FROM [dbo].[FactSalesQuota] 
--GO
SELECT * FROM [dbo].[FactSurveyResponse] 
--GO
SELECT * FROM [dbo].[ProspectiveBuyer] 
--GO
SELECT * FROM [dbo].[FactProductInventory] 
--GO
SELECT * FROM [dbo].[FactAdditionalInternationalProductDescription] 
--GO
SELECT * FROM [dbo].[sysdiagrams] 
--GO
SELECT * FROM [dbo].[DatabaseLog] 
--GO
SELECT * FROM [dbo].[AdventureWorksDWBuildVersion] 
--GO
COMMIT;

WAITFOR DELAY '00:00:01';
