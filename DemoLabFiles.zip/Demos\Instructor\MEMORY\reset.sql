EXEC sys.sp_configure N'max server memory (MB)', N'6000'
GO
RECONFIGURE WITH OVERRIDE
GO
