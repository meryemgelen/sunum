EXEC sys.sp_configure N'max server memory (MB)', N'1500'
GO
RECONFIGURE WITH OVERRIDE
GO

USE AdventureWorksPTO
GO
