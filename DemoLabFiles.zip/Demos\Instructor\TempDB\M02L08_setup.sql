DECLARE @fileName sysname
DECLARE @sql nvarchar(max)

while exists(SELECT * FROM sys.master_files WHERE database_id=2 and file_id>2)
begin

	SELECT TOP 1 @fileName=[name] FROM sys.master_files WHERE database_id=2 and file_id>2
		SET @sql ='
	USE [tempdb];
	DBCC SHRINKFILE ('+@fileName+', EMPTYFILE);
	DBCC DROPCLEANBUFFERS
	DBCC FREEPROCCACHE
	DBCC FREESESSIONCACHE
	DBCC FREESYSTEMCACHE ( ''ALL'')
	ALTER DATABASE [tempdb]  REMOVE FILE ['+@fileName+']'

	EXECUTE (@sql)
end