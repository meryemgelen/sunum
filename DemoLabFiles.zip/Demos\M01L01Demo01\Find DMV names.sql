/* This Sample Code is provided for the purpose of illustration only and is not intended 
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE 
PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR 
PURPOSE.  We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
and to reproduce and distribute the object code form of the Sample Code, provided that You 
agree: (i) to not use Our name, logo, or trademarks to market Your software product in which
the Sample Code is embedded; (ii) to include a valid copyright notice on Your software product
in which the Sample Code is embedded; and (iii) to indemnify, hold harmless, and defend Us and
Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or 
result from the use or distribution of the Sample Code.
*/
-- Author: boB 'The Toolman' Taylor
-- 2/14/2020
-- put in the subsystem you are interested in such as os, exec, or hadr
-- we then identify the dmvs (and exclude DMFs) by using @SearchViews
-- and parse out the rest of the definition by using @SearchTerm
DECLARE @SubSystem NVARCHAR(50) = N'tran';
DECLARE @SearchViews NVARCHAR(50) = N'%VIEW sys.dm[_]' + @SubSystem + '%';
DECLARE @SearchTerm NVARCHAR(50) = N'%' + SUBSTRING(@SearchViews, 6, (LEN(@SearchViews)-5));

SELECT[dmv name] = SUBSTRING(definition, PATINDEX(@SearchTerm, definition)
-- we have to search for 'as' plus whitespace to avoid 'as' within the dmv
, PATINDEX(N'%AS[^0-9a-z]%', definition) - PATINDEX(@SearchTerm, definition))
FROM
  sys.all_sql_modules
WHERE  definition LIKE @SearchViews;
GO 
