/*------------------------------------------------------------------------------ 
* Copyright � 2020 Microsoft Corporation.  All rights reserved. 
* 
* THIS CODE AND ANY ASSOCIATED INFORMATION ARE PROVIDED �AS IS� WITHOUT 
* WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
* FOR A PARTICULAR PURPOSE. THE ENTIRE RISK OF USE, INABILITY TO USE, OR  
* RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER. 
* 
*------------------------------------------------------------------------------ 
* TRANSACT-SQL Code 
* 
* Description: 
*    This script aims to explain the SQL Server Object allocation AlGOrithm the  
*    and the behind the scene activities when a row is inserted into the table. 
* 
* VERSION: 
*    1.0 Developed for SQL Server 2019
*------------------------------------------------------------------------------*/
USE master;
GO
IF(DB_ID('SQLFilesFilegroups') is not null)
BEGIN
	DROP DATABASE SQLFilesFilegroups
END 
-- Create the database with the default data
-- filegroup and a log file. Specify the
-- growth increment and the max size for the
-- primary data file.
CREATE DATABASE SQLFilesFilegroups
ON PRIMARY
  ( NAME='SQLFilesFilegroups_Primary',
    FILENAME=
       'F:\SQLData\SQLFilesFilegroups_Prm.mdf',
    SIZE=4MB,
    MAXSIZE=10MB,
    FILEGROWTH=1MB),
FILEGROUP SQLFilesFilegroups_FG1
  ( NAME = 'SQLFilesFilegroups_FG1_Dat1',
    FILENAME =
       'F:\SQLData\SQLFilesFilegroups_FG1_1.ndf',
    SIZE = 1MB,
    MAXSIZE=10MB,
    FILEGROWTH=1MB),
  ( NAME = 'SQLFilesFilegroups_FG1_Dat2',
    FILENAME =
       'F:\SQLData\SQLFilesFilegroups_FG1_2.ndf',
    SIZE = 1MB,
    MAXSIZE=10MB,
    FILEGROWTH=1MB)
LOG ON
  ( NAME='SQLFilesFilegroups_log',
    FILENAME =
       'F:\SQLLog\SQLFilesFilegroups.ldf',
    SIZE=1MB,
    MAXSIZE=10MB,
    FILEGROWTH=1MB);
GO
ALTER DATABASE SQLFilesFilegroups 
  MODIFY FILEGROUP SQLFilesFilegroups_FG1 DEFAULT;
GO

-- Review the logical and physical names for the files
SELECT * FROM sys.master_files WHERE database_id= DB_ID('SQLFilesFilegroups')
GO

USE [SQLFilesFilegroups]
GO
-- Review the database filegroups
SELECT * FROM sys.filegroups
GO
-- Review the logical and physical names for the files
-- If you are working with AlwaysOn AG and you placed the database files on a different location for a Secondary database, sys.database_files will gives you the information of the Primary Replica.
SELECT * FROM sys.database_files
GO
