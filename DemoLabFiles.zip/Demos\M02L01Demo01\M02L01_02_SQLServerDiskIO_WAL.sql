/*------------------------------------------------------------------------------ 
* Copyright � 2020 Microsoft Corporation.  All rights reserved. 
* 
* THIS CODE AND ANY ASSOCIATED INFORMATION ARE PROVIDED �AS IS� WITHOUT 
* WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
* FOR A PARTICULAR PURPOSE. THE ENTIRE RISK OF USE, INABILITY TO USE, OR  
* RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER. 
* 
*------------------------------------------------------------------------------ 
* TRANSACT-SQL Code 
* 
* Description: 
*    This script aims to explain the SQL Server Object allocation AlGOrithm the  
*    and the behind the scene activities when a row is inserted into the table. 
* 
* VERSION: 
*    1.0 Developed for SQL Server 2019
*------------------------------------------------------------------------------*/

/*
This section describes the role of the write-ahead transaction log in recording data modifications to disk. 
SQL Server uses a write-ahead logging (WAL) algorithm, which guarantees that no data modifications are written to disk before the associated log record is written to disk. 
This maintains the ACID properties for a transaction.

To understand how the write-ahead log works, it is important for you to know how modified data is written to disk:
- SQL Server maintains a buffer cache into which it reads data pages when data must be retrieved. 
- When a page is modified in the buffer cache, it is not immediately written back to disk; instead, the page is marked as dirty. 
- A data page can have more than one logical write made before it is physically written to disk. 
- For each logical write, a transaction log record is inserted in the log cache that records the modification. 
- The log records must be written to disk before the associated dirty page is removed from the buffer cache and written to disk. 
- The checkpoint process periodically scans the buffer cache for buffers with pages from a specified database and writes all dirty pages to disk. 
- Checkpoints save time during a later recovery by creating a point at which all dirty pages are guaranteed to have been written to disk.

Writing a modified data page from the buffer cache to disk is called flushing the page. 
- SQL Server has logic that prevents a dirty page from being flushed before the associated log record is written. 
- Log records are written to disk when the log buffers are flushed. This happens whenever a transaction commits or the log buffers become full.
*/
USE [master]
GO
-- Starting SQL Server 2016 (13.x) Indirect checkpoint is the default behavior 
-- it uses a background Recovery Writer thread that serves to smooth out the I/O spikes that would occur during normal checkpoints
-- the default value is 1 minute

-- ### 1.- For demo purposes TARGET_RECOVERY_TIME = 10 SECONDS
ALTER DATABASE [AdventureWorksPTO] SET TARGET_RECOVERY_TIME = 10 SECONDS WITH NO_WAIT 
GO

-- ### 2.- Open the M02L01_02_PerfCounters.perfmoncfg

USE [AdventureWorksPTO]
GO

-- ### 3.- Claer the buffer
-- Run the following two statements to clear the buffer pool
-- Note that you may need to run these more than once to get the entire pool clear
CHECKPOINT
GO
DBCC DROPCLEANBUFFERS
GO

-- ### 4.- Clear the Perfmon window
-- Place Data Pages in the buffer pool.
SET NOCOUNT ON
SET STATISTICS IO ON

SELECT * 
FROM Production.Product
WHERE Color='Black'

SET STATISTICS IO OFF
GO

-- ### 5.- Go to perfmon and review the metrics for the Page reads/sec

--(93 rows affected)
--Table 'Product'. Scan count 1, logical reads 15, physical reads 1, page server reads 0, read-ahead reads 20

--Read-ahead anticipates the data and index pages needed to fulfill a query execution plan and brings the pages into the buffer cache before they are actually used by the query. 
--This allows computation and I/O to overlap, taking full advantage of both the CPU and the disk.


-- ### 5.- Start the transaction
BEGIN TRANSACTION

	UPDATE Production.Product
	SET SafetyStockLevel+=10
	WHERE Color='Black'
GO
--Modification is recorded in the log cache
--The affected data pages are in the buffer cache and were modified.
--Since the transaction is open and the log cache is not fully filled then there is no activity in the selected perf counters.

-- ### 6.- Commit the transaction
COMMIT TRANSACTION
GO

-- The background writer pages is not used because a data page can have more than one logical write made before it is physically written to disk. 
-- SQL Server will decide based on the Target Recovery Time.
-- A single transaction is not enough

-- ### 7.- Work with many transactions 
-- Check the background Recovery Writer thread
DROP TABLE IF EXISTS t1
GO
CREATE TABLE t1 (c1 int, c2 varchar(100))
go
-- compare
-- scanerio 1 hit 20K implicit transactions 
PRINT GETDATE()
DECLARE @i int=0
WHILE (@i<20000)
BEGIN
	INSERT INTO t1 VALUES (@i,'Some text')
	SET @i+=1
END
GO

--The interesting counters here are:
--* Background Writer Pages/sec  (for Indirect Checkpints)
--* Pages write/sec
--As you can see those counters raised in intervals of 10 seconds as you configured in step #1
--Finally the counters Checkpoint pages/sec and Lazy writes are not used as those counters represent automatic checkpoints.


-- ### 8.- Insert the same amount of data but with a single transaction
-- Check the if background Recovery Writer thread is raised
DROP TABLE IF EXISTS t1
GO
CREATE TABLE t1 (c1 int, c2 varchar(100))
go
-- compare
-- scanerio 2 hit 1 explicit transactions to insert 20K rows
PRINT GETDATE()
BEGIN TRAN
	DECLARE @i int=0
	WHILE (@i<20000)
	BEGIN
		INSERT INTO t1 VALUES (@i,'Some text')
		SET @i+=1
	END
COMMIT TRAN
GO


-- ### 9.- Set the target recovery time = 0 to get back to automatic checkpoints
-- Repeat the exercise starting the step #2
-- Check the performance counters Checkpoint Pages/sec and Lazy Writes/sec.

USE [master]
GO
ALTER DATABASE [AdventureWorksPTO] SET TARGET_RECOVERY_TIME = 0 SECONDS WITH NO_WAIT 
GO
