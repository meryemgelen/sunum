﻿# Navigate to the DiskSpd folder
CD E:\Demos\M02L02Demo01\DiskSpd-2.0.21a\amd64

# Execute the following tests and analyze the results.

## Review disk performance for sequential IO operations (TransactionLog)
.\diskspd.exe -c5G -d20 -w100 -t4 -o1 -b60K -Sh -L F:\testfile.dat -si

## Review disk performance for random IO operations (OLTP)
.\diskspd.exe -c5G -d20 -r -w80 -t4 -o1 -b64K -Sh -L F:\testfile.dat

## Review disk performance for sequential IO operations (Table Scan)
.\diskspd.exe -c5G -d20 -w0 -t4 -o1 -b512K -Sh -L F:\testfile.dat -si
