/* 
This Sample Code is provided for the purpose of illustration only and is not intended
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE
PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
PURPOSE.  We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
and to reproduce and distribute the object code form of the Sample Code, provided that You
agree: (i) to not use Our name, logo, or trademarks to market Your software product in which
the Sample Code is embedded; (ii) to include a valid copyright notice on Your software product
in which the Sample Code is embedded; and (iii) to indemnify, hold harmless, and defend Us and
Our suppliers from and against any claims or lawsuits, including attorneys fees, that arise or
result from the use or distribution of the Sample Code.
*/

-- #1 Start the scenario
--From 'E:\Demos\Instructor\DISK', start Scenario.cmd to generate some OLTP background workload. 


-- #2 Review the exec requests and notice the sessions in suspended state.
-- Notice that the requests has no waits
SELECT 
er.session_id, er.status, er.wait_type, er.wait_resource,
er.blocking_session_id, er.command,
SUBSTRING(st.text, (er.statement_start_offset/2) + 1,  
    ((CASE statement_end_offset   
        WHEN -1 THEN DATALENGTH(ST.text)  
        ELSE er.statement_end_offset END   
            - er.statement_start_offset)/2) + 1) AS statement_text,er.*
FROM sys.dm_exec_requests  as er
  INNER JOIN sys.dm_exec_sessions as es on er.session_id=es.session_id
  CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) as st
WHERE es.is_user_process=1 and er.session_id<>@@SPID
GO

-- #3 Identify the page contention.
-- Notice that the requests has no waits
SELECT 
er.session_id, er.status, er.wait_type, er.wait_resource,
OBJECT_NAME(page_info.[object_id],page_info.[database_id]) as [object_name], 
er.blocking_session_id, er.command,
SUBSTRING(st.text, (er.statement_start_offset/2) + 1,  
    ((CASE statement_end_offset   
        WHEN -1 THEN DATALENGTH(ST.text)  
        ELSE er.statement_end_offset END   
            - er.statement_start_offset)/2) + 1) AS statement_text,
			page_info.database_id,
			page_info.[file_id],
			page_info.page_id,
			page_info.[object_id],
			page_info.index_id,
			page_info.page_type_desc
FROM sys.dm_exec_requests AS er
  CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) as st
  CROSS APPLY sys.fn_PageResCracker(er.page_resource) AS r
  CROSS APPLY sys.dm_db_page_info(r.db_id, r.file_id, r.page_id,'DETAILED') AS page_info;
GO

-- #4 Analyze Pending IOS
-- View pending IO:
SELECT iop.io_type, iop.io_pending, iop.io_pending_ms_ticks, iop.io_completion_request_address, iop.io_handle, iop.scheduler_address, DB_NAME(vfs.database_id) AS database_name, 
	smf.name AS logical_filename, smf.physical_name AS physical_filename, 
	vfs.io_stall_read_ms, vfs.io_stall_write_ms, vfs.io_stall
FROM sys.dm_io_pending_io_requests iop
INNER JOIN sys.dm_io_virtual_file_stats(NULL, NULL) vfs ON iop.io_handle = vfs.file_handle
INNER JOIN sys.master_files smf ON vfs.database_id = smf.database_id AND vfs.file_id = smf.file_id
GO

-- #5 Review virtual file stats.
-- Open the Performace Dashboard report and Analyze the Historical IO Report

-- #6 Review Latches
-- E:\Demos\M02L03Demo01\M02L03_view_Latches.sql

-- #7 Review Waits
-- E:\Demos\M02L03Demo01\M02L03_view_Waits.sql

-- #8 Analyze some performance counters
-- 
