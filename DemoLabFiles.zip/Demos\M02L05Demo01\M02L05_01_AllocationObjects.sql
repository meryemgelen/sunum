/*------------------------------------------------------------------------------ 
* Copyright � 2020 Microsoft Corporation.  All rights reserved. 
* 
* THIS CODE AND ANY ASSOCIATED INFORMATION ARE PROVIDED �AS IS� WITHOUT 
* WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
* FOR A PARTICULAR PURPOSE. THE ENTIRE RISK OF USE, INABILITY TO USE, OR  
* RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER. 
* 
*------------------------------------------------------------------------------ 
* TRANSACT-SQL Code 
* 
* Description: 
*    This script aims to explain the SQL Server Object allocation AlGOrithm the  
*    and the behind the scene activities when a row is inserted into the table. 
* 
* VERSION: 
*    1.0 Developed for SQL Server 2014
*    2.0 Adjusted for SQL Server 2019 (Including new DMV's)
*------------------------------------------------------------------------------*/
USE [master]
GO

IF(DB_ID('SQLDataStructures') is not null)
BEGIN
	DROP DATABASE SQLDataStructures
END 

CREATE DATABASE SQLDataStructures
GO

ALTER DATABASE SQLDataStructures Set Recovery SIMPLE
GO

USE SQLDataStructures
GO 

IF(object_id('SQLObjectAllocation') is not null)
BEGIN
	DROP TABLE SQLObjectAllocation
END 

CREATE TABLE SQLObjectAllocation (Col1 int, Col2 float, Col3 varchar(2000), Col4 datetime, Col5 varchar(1000))
GO

/*
Running a Create Table command does not mean there would be page allocation for the table. 
Create table would just make meta data entires into the System Tables (sys.object, sys.tables etc..) 
*/

-- Logically SQL Server groups pages from a given index, and partition into a logical units called allocation units.
-- There are three different allocation units:
-- * IN_ROW_DATA
-- * LOB_DATA
-- * ROW_OVERFLOW_DATA

-- Note: type_desc = IN_ROW_DATA, total_pages = o for that particular allocation unit.

SELECT * 
FROM sys.allocation_units AS [au]
INNER JOIN sys.partitions AS [pr] on au.container_id=pr.partition_id
WHERE pr.object_id=object_id('SQLObjectAllocation')
GO

SELECT * FROM sys.dm_db_database_page_allocations(DB_ID(),object_id('SQLObjectAllocation'),null,null,'LIMITED')
GO
-- (0 rows affected)

-- Insert 1 record into the table. At this point, a New page would be allocated to the table (coming from a Uniform Extent)
-- Starting with SQL Server 2016 (13.x), the default for all allocations in the database is uniform extents.
-- Additionally a IAM page would also be allocated to the table.
-- Notice the Record Size for the Table would be 3020 Bytes + Row Header Information 
INSERT INTO SQLObjectAllocation VALUES (1,2.0,Replicate ('A',2000), getdate(), Replicate('B',1000))
GO


-- Notice that the table called SQLObjectAllocation has a total of 9 pages where two of them are used.
SELECT * 
FROM sys.allocation_units AS [au]
INNER JOIN sys.partitions AS [pr] on au.container_id=pr.partition_id
WHERE pr.object_id=object_id('SQLObjectAllocation')
GO


-- Review the detail of the 9 pages.
-- Take note of the following information:
-- extend_page_id = ___ and ___
-- allocated_page_iam_page_id= ___
-- note the page_id of the first two records where is allocated = 1, page_id = ___ and ___

SELECT * FROM sys.dm_db_database_page_allocations(DB_ID(),OBJECT_ID('SQLObjectAllocation'),null,null,'LIMITED')
GO

-- The object is composed by 9 pages:
-- 1 IAM page allocated into a mixed extend
-- 8 Data Pages (allocated into a unifirm extend) where
--    1 Data Page is allocated and and 50 percent of free space
--    7 Data Pages are not allocated just reserved


-- Let's Look at the IAM page (might need to change the Page Number)
-- sys.dm_db_page_info is currently supported only in SQL Server 2019 (15.x) and later.
-- Returns information about a page in a database. 
-- The function returns one row that contains the header information from the page, including the object_id, index_id, and partition_id. 
-- This function replaces the need to use DBCC PAGE in most cases.

SELECT * FROM sys.dm_db_page_info(DB_ID(),1,228,'DETAILED')
GO
/*
GAM (1:2) = ALLOCATED               SGAM (1:3) = ALLOCATED              
PFS (1:1) = 0x70 IAM_PG MIXED_EXT ALLOCATED   0_PCT_FULL                 DIFF (1:6) = CHANGED
ML (1:7) = NOT MIN_LOGGED           
*/

-- View first data page for the SQLObjectAllocation object
SELECT * FROM sys.dm_db_page_info(DB_ID(),1,312,'DETAILED')
GO
/*
GAM (1:2) = ALLOCATED               SGAM (1:3) = NOT ALLOCATED          PFS (1:1) = 0x41 ALLOCATED  50_PCT_FULL
DIFF (1:6) = CHANGED                ML (1:7) = NOT MIN_LOGGED     
*/

-- We need to use DBCC Page to view the slot array.

Select db_id() -- Note down the Database ID, we would need it in the subsequent commands.
GO
DBCC TRACEON (3604,-1)
GO

-- view first data page for the SQLObjectAllocation object
--m_type.
DBCC PAGE (<db_id>, 1, <page_id>, 3)
GO

--- Let's look at the other Pages 
-- view first PFS page in file 1, the first PFS page is page 1 of the data file, verify this by looking at the page type field, 
--m_type.
DBCC PAGE (<db_id>, 1, 1, 3)
GO

-- view first GAM page in file 1, the first GAM page is page 2 of the data file, verify this by looking at the page type field, 
--m_type.
DBCC PAGE (<db_id>, 1, 2, 3)
GO

-- view first SGAM page in file 1, the first SGAM page is page 3 of the data file, verify this by looking at the page type field, 
--m_type.
DBCC PAGE (<db_id>, 1, 3, 3)
GO

/*
Example:
Review PFS
DBCC PAGE (6, 1, 1, 3)
Review GAM
DBCC PAGE (6, 1, 2, 3)
Review SGAM
DBCC PAGE (6, 1, 3, 3)
*/
