/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  
THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  
We grant You a nonexclusive, royalty-free right to use and modify the 
Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
(ii) to include a valid copyright notice on Your software product in which the Sample Code is 
embedded; and 
(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/

--Backup demo

/* First - lets  use the new XE ( since SQL 2016) to check our backup:
backup_restore_progress_trace - Prints backup/restore progress trace messages with details
databases_backup_restore_throughput */  

IF EXISTS (SELECT name FROM sys.dm_xe_sessions  WHERE name = 'Backup_XE')
	DROP EVENT SESSION [Backup_XE] ON SERVER
GO

-- review TARGET LOCATION for your SYSTEM
CREATE EVENT SESSION [Backup_XE] ON SERVER 
ADD EVENT sqlserver.backup_restore_progress_trace(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.server_principal_name,sqlserver.session_id,sqlserver.session_nt_username,sqlserver.username)),
ADD EVENT sqlserver.databases_backup_restore_throughput(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.server_principal_name,sqlserver.session_id,sqlserver.session_nt_username,sqlserver.username))
ADD TARGET package0.event_file(SET filename=N'E:\Demos\M02L06Demo02\Backup_XE.xel')
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

-- start the XEvent session
ALTER EVENT SESSION [Backup_XE] 
ON SERVER 
STATE = Start;


---Start the session and Watch live data

/* Setup - New database with some information */  

USE MASTER;
GO
DROP DATABASE IF EXISTS SmartBackup ; 
GO
CREATE DATABASE SmartBackup
GO
USE SmartBackup
GO
CREATE TABLE [dbo].[tableforbackup]
   (
   [tbf_id] [int] IDENTITY(1,1) NOT NULL,
   [tfb_name] [varchar](50) NOT NULL
   ) 
GO
SET NOCOUNT ON
GO
USE SmartBackup
GO
INSERT INTO [tableforbackup] VALUES ('Smart Backups')
GO 2500

--Full database backup
BACKUP DATABASE [SmartBackup] TO DISK = N'SmartBackup.bak'  
WITH FORMAT
GO

--Transaction log backup
USE SmartBackup
GO
BACKUP LOG [SmartBackup] TO DISK = N'Smartbackup.trn'	
WITH FORMAT
GO

/*
-- explain the old method:
-- =======================
-- I would create a job and schedule to run backup from time to time

SET NOCOUNT ON
WHILE (1=1)
BEGIN
	BACKUP LOG [SmartTrasactionLogBackup] 
		TO DISK = N'Smartbackup.trn'	--> <Replace the path>
		WITH FORMAT, 
		NAME = N'Smar Log Database Backup', 
		SKIP, 
		NOREWIND, 
		NOUNLOAD, 
		STATS = 10

	--Timer to run the script for backup every 1 min
	WAITFOR DELAY '00:01:00' 
end
GO
*/

/*
-- explain the NEW method with new DMV sys.dm_db_log_stats:
-- ========================================================
-- Now it is possible to manage when to run the backup
-- based on amount of data recorded in T-LOG
*/
USE SmartBackup
GO
SELECT 
      DB_NAME(database_id) AS DBName, 
      recovery_model,				--recovery_model: Current database recovery model i.e. Full, Bulk-logged, Simple.
      total_log_size_mb,			--Total transaction log size in MB.
      active_log_size_mb,			--Total active transaction log size in MB.
      active_vlf_count,				--Total number of active VLFs in the transaction log.
      log_truncation_holdup_reason,	--Log truncation holdup reason. The value is same as log_reuse_wait_desc column of sys.databases.
      log_backup_time,				--Last transaction log backup time.
      log_since_last_log_backup_mb	--Log size in MB since last transaction log backup LSN.
FROM 
	sys.dm_db_log_stats(DB_ID())


--For example, suppose I want log backups to happen only when log_since_last_log_backup_mB reachs a determined threshold. 

-- COPY THIS INSERT BLOCK TO ANOTHER WINDOW
-- make the new window to be visible in a vertical pane
	--Lets insert some data!
USE SmartBackup
GO
SET NOCOUNT ON;
INSERT INTO [tableforbackup] VALUES ('Smart Backups')
GO 800

-----CHECK the size of my log since last backup
SELECT 
    DB_NAME(database_id) AS DBName, 
    recovery_model,
    total_log_size_mb,
    active_log_size_mb,
    active_vlf_count,
    log_truncation_holdup_reason,
    log_backup_time,
    log_since_last_log_backup_mb
FROM 
	sys.dm_db_log_stats(DB_ID())

-- 
-- NOW we will HIGHLIGHT this code block 
-- and execute it repeated times
-- while we execute the insert in the separate window
--	     execute the insert block 2 or 3 times 
--		 so it will generate t-log volume that exceeds the threshold
--
DECLARE @log_since_last_log_backup_mb int
DECLARE @log_threshold int=1 --> QUITE LOW THRESHOLD FOR THE PURPOSE OF THE DEMO

SELECT @log_since_last_log_backup_mb = log_since_last_log_backup_mb from sys.dm_db_log_stats(DB_ID())

SELECT @log_threshold AS 'Threshold',   @log_since_last_log_backup_mb AS 'log_since_last_log_backup_mb'

IF (@log_threshold <= @log_since_last_log_backup_mb )
BEGIN
	Select ' Threshold reached - ' + cast (@log_threshold as char (2)) + 'MB  - log backup' 

	SELECT 
		DB_NAME(database_id) AS DBName, 
		recovery_model,
		total_log_size_mb,
		active_log_size_mb,
		active_vlf_count,
		log_truncation_holdup_reason,
		log_backup_time,
		log_since_last_log_backup_mb
	FROM sys.dm_db_log_stats(DB_ID())

    BACKUP LOG [SmartBackup] TO DISK = N'Smartbackup.trn'	
	WITH FORMAT

END
ELSE 
BEGIN
	Select ' Threshold NOT reached - ' + cast (@log_threshold as char (2)) + 'MB greater than ' + cast (@log_since_last_log_backup_mb as char (2))  + 'MB - log_since_last_log_backup_mb' 
END

--Check extended event session and show the backup progress.


--And for Differential backups?

SELECT ( 100 * Sum(modified_extent_page_count) / Sum(total_page_count) )  as ModifiedPagesPcnt
FROM sys.dm_db_file_space_usage 

--We can use sys.dm_db_file_space_usage ( and track modified extent page count) to determine how much my Database change. 
--If it changed more than 30% I should do a full backup otherwise a full backup


-- READ from XEL file
-- open the XEL file directly into SSMS to show the capture




--Clean the enviromnent
Use Master
GO
Drop Database SmartBackup
go
-- Stop the XEvent session
ALTER EVENT SESSION [Backup_XE] 
ON SERVER 
STATE = stop;
go
DROP EVENT SESSION [Backup_XE] ON SERVER 
GO

--End