/* This Sample Code is provided for the purpose of illustration only and is not intended 
to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE 
PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR 
PURPOSE.  We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
and to reproduce and distribute the object code form of the Sample Code, provided that You 
agree: (i) to not use Our name, logo, or trademarks to market Your software product in which
the Sample Code is embedded; (ii) to include a valid copyright notice on Your software product
in which the Sample Code is embedded; and (iii) to indemnify, hold harmless, and defend Us and
Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or 
result from the use or distribution of the Sample Code.
*/

-- Let's look at the NUMA configuration for this machine
-- error log, log type, search term1, search term2, startdate, enddate, sortorder
EXEC xp_ReadErrorLog 0, 1, N'Numa'
exec xp_readerrorlog 0, 1, N'',N'','2020-02-14 16:29:00'

---- View the various memory clerks and their current memory allocations by name and memory node
--SELECT type, name, memory_node_id
--	, sum(pages_kb 
--		+ virtual_memory_committed_kb 
--		+ awe_allocated_kb 
--		+ shared_memory_committed_kb) AS TotalKB
--FROM sys.dm_os_memory_clerks
--GROUP BY type, name, memory_node_id
--ORDER BY TotalKB DESC

---- View the current state of the memory brokers
---- Note the current memory, the predicted future memory, the target memory and whether the memory is growing, shrinking or stable

--SELECT p.name AS resource_governor_pool_name, b.memory_broker_type
--	, b.allocations_kb AS current_memory_allocated_kb
--	, b.allocations_kb_per_sec AS allocation_rate_in_kb_per_sec
--	, b.future_allocations_kb AS near_future_allocations_kb
--	, b.target_allocations_kb
--	, b.last_notification AS last_memory_notification
--FROM sys.dm_os_memory_brokers b
--INNER JOIN sys.resource_governor_resource_pools p ON p.pool_id = b.pool_id