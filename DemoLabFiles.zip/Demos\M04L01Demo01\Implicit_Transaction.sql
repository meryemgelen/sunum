/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  
THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  
We grant You a nonexclusive, royalty-free right to use and modify the 
Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
(ii) to include a valid copyright notice on Your software product in which the Sample Code is 
embedded; and 
(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/
----Session 1 ---- 
--Note Down Session Id---
USE ADVENTUREWORKSPTO
GO
SET IMPLICIT_TRANSACTIONS ON;
GO
SELECT * 
FROM [PRODUCTION].[PRODUCT]
GO
--Commit
 --Rollback
------------------------------------------------------------------------------------------------
-----------After Running Above Statement  -------------------------------------------
----------Run the following Statement in New Window-----------------------------
------------------------------------------------------------------------------------------------
--==========================
--- RUN in Session 2
--===========================
USE ADVENTUREWORKSPTO
GO
SELECT  
Case
	WHEN transaction_isolation_level= 0 THEN  'Unspecified'
	WHEN transaction_isolation_level= 1 THEN 'ReadUncommitted'
	WHEN transaction_isolation_level= 2 THEN 'ReadCommitted'
	WHEN transaction_isolation_level=3 THEN 'RepeatableRead'
	WHEN transaction_isolation_level=4 THEN 'Serializable'
	WHEN transaction_isolation_level=5  THEN 'Snapshot'
ENd IsolationLevel, S.*
FROM sys.dm_exec_sessions AS s  where open_transaction_count>0

--This is will show that "Session 1" Transaction is still open in server even when we never use BEGIN TRANSACTION
--Run the commit/Rollback statement 
--Again run the following  statement in session 2 window 
--==========================
--- RUN in Session 2
--===========================
USE ADVENTUREWORKSPTO
GO
SELECT  
Case
	WHEN transaction_isolation_level= 0 THEN  'Unspecified'
	WHEN transaction_isolation_level= 1 THEN 'ReadUncommitted'
	WHEN transaction_isolation_level= 2 THEN 'ReadCommitted'
	WHEN transaction_isolation_level=3 THEN 'RepeatableRead'
	WHEN transaction_isolation_level=4 THEN 'Serializable'
	WHEN transaction_isolation_level=5  THEN 'Snapshot'
ENd IsolationLevel, S.*
FROM sys.dm_exec_sessions AS s  where open_transaction_count>0

--this time there will be no open transaction

---Point is that it is side effect of Implicit transactions which keep the transaction open until commit/rollback is not used
--- explicitly in coding and that can impact the performance in very busy OLTP environment 
----------------------
-----Optional -----
----------------------
--Now you can repeat the same steps for DML statements
SET IMPLICIT_TRANSACTIONS ON;
GO
Update [PRODUCTION].[PRODUCT]
	Set [MakeFlag] = 1
	where ProductID=1
go
--Rollback
--==========================
--- RUN in Session 2
--===========================
---Now if you use select * from [PRODUCTION].[PRODUCT] where ProductID=1 it will never get completed and 
---following statement will still show open update transaction started by session 1
USE ADVENTUREWORKSPTO
GO
SELECT  
Case
	WHEN transaction_isolation_level= 0 THEN  'Unspecified'
	WHEN transaction_isolation_level= 1 THEN 'ReadUncommitted'
	WHEN transaction_isolation_level= 2 THEN 'ReadCommitted'
	WHEN transaction_isolation_level=3 THEN 'RepeatableRead'
	WHEN transaction_isolation_level=4 THEN 'Serializable'
	WHEN transaction_isolation_level=5  THEN 'Snapshot'
ENd IsolationLevel, S.*
FROM sys.dm_exec_sessions AS s  where open_transaction_count>0
--Now Run Rollback statement in "session 1" then it will complete the transaction and select will also work

----CleanUp
SET IMPLICIT_TRANSACTIONS OFF;
