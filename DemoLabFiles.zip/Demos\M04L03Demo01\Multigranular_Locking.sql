/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  
THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  
We grant You a nonexclusive, royalty-free right to use and modify the 
Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
(ii) to include a valid copyright notice on Your software product in which the Sample Code is 
embedded; and 
(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/

USE master
GO

If db_id('LockingDemo') is not null
	Drop Database LockingDemo
Go

Create Database LockingDemo
Go

Use LockingDemo
Go

-- Let's create a partitioned table 
CREATE PARTITION FUNCTION PartFunc1 (int) 
AS RANGE RIGHT FOR VALUES (100,200,300)
GO
--Create partition scheme

CREATE PARTITION SCHEME PartSch1
AS PARTITION PartFunc1
ALL TO ([PRIMARY])
GO

Create Table LockingTest
(
col1 int,
col2 varchar(20),
col3 datetime
)On PartSch1(col1)


-- Let's insert a 1 record into the table and check the locks being generated
Begin Tran
Insert into LockingTest values (1, 'FirstRecord',getdate())

Select * from sys.dm_tran_locks where request_session_id = @@SPID
-- We should see 4 locks in this case 
-- 1 RID Lock (X), 2 IX locks (Object and Page) and 1 S lock on the DB

Commit 
-- Rerun the sys.dm_tran_locks query 
Select * from sys.dm_tran_locks where request_session_id = @@SPID
-- Now we should see only one lock

--- Let's insert a few more records in the table.
Set NoCount on
Declare @count int = 2
while @count <=350
begin
insert into LockingTest values (@count, 'Record'+cast(@count as char(4)),getdate())
set @count += 1
end 

-- Let's see the locks held when doing a Select operation
Set Transaction Isolation Level Repeatable Read -- This is needed or else the locks would be release immediately after the operation
Begin Tran
Select * from LockingTest
-- 350 Records Returned

--- how many Locks would be see... 
Select * from sys.dm_tran_locks where request_session_id = @@SPID -- 356 Records
order by resource_type
-- Why 356??
-- 350 for the RID (Shared Locks)
-- 1 Shared at DB Level 
-- 1 IS at Object Level
-- 4 Page Level (the average record size for the table is 33 Bytes) and there are 4 partitions 
Select * from sys.partitions where object_id = object_id('LockingTest')
--- Each partitition will have one page in this example -- hence 4 pages.
Commit
--- What happens if we just select 1 record
Begin Tran
Select * from LockingTest where col1 = 100

--- how many Locks would be see... 
Select * from sys.dm_tran_locks where request_session_id = @@SPID -- 4 Records
Commit

-- Let's insert some more records to the table (such that record count is grater than 5000)
Set NoCount on
declare @outerloop int = 1
declare @count int
while @outerloop <=200
begin
	set @count = 1
	while @count <=350
	begin
	insert into LockingTest values (@count, 'Record'+cast(@count as char(4)),getdate())
	set @count += 1
	end 
Set @outerloop +=1
end


-- Select count(*) from LockingTest
------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Extended Event ----------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
--- Let's create a XE session to monitor Lock Escalations
CREATE EVENT SESSION [Lock Escalation] ON SERVER 
ADD EVENT sqlserver.lock_escalation(SET collect_database_name=(1),collect_statement=(1)) 
ADD TARGET package0.ring_buffer
GO

ALTER EVENT SESSION [Lock Escalation] ON SERVER
STATE = start;
GO

-- Watch Live Data 
--- Run the below Select query 

begin Tran
Select * from LockingTest 

-- Check the locks 
Select * from sys.dm_tran_locks where request_session_id = @@SPID 
-- We should see only 2 locks (1 at the DB Level and another one at the Object Level)
-- check the LockEscalation XE live Data
Commit

--- Change the Table Lock Escalation to AUTO
Alter Table lockingTest Set (lock_escalation = Auto)

begin Tran
Select * from LockingTest 

-- Check the locks 
Select * from sys.dm_tran_locks where request_session_id = @@SPID 
-- We should see  6 locks now (The escalation is now at the Partition Level)
-- check the LockEscalation XE live Data
Commit

-----CleanUp------
Use Master
go
If db_id('LockingDemo') is not null
	Drop Database LockingDemo
Go
DROP EVENT SESSION [Lock Escalation] ON SERVER 
GO


