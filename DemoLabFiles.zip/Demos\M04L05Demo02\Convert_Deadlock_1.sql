/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  
THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  
We grant You a nonexclusive, royalty-free right to use and modify the 
Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
(ii) to include a valid copyright notice on Your software product in which the Sample Code is 
embedded; and 
(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys’ fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/

/*
In this demo, we will show you convert type deadlock. 

You can use below methods to capture deadlock senarios:
1. dbcc traceon(1222,-1), will record deadlock into SQL Errorlog
2. Use system_health session deadlock graph event

For the purposes of this demo, we will be using method 2.
*/

USE AdventureWorksPTO;
GO

-- 1. Hold read lock 
BEGIN TRANSACTION;

SELECT *
FROM   Person.Address WITH (HOLDLOCK)
WHERE  AddressID = 100;

/***************************************************************************
Open the Lesson5-Convert_Deadlock_2.sql and execute the queries.
***************************************************************************/

-- Observe the other session is holding U lock and waiting on X lock convert
SELECT *
FROM   sys.dm_tran_locks; -- where request_session_id = @@SPID

-- 3. Run update again to trigger convert deadlock
UPDATE        Person.Address
          SET AddressLine2 = 'abc'
WHERE         AddressID = 100;

-- Now these two connections would result in deadlock and we've just 
-- observed the flow of converting a shared lock into a deadlock situation

-- After the deadlock occurs, browse to the system_health session
-- in SSMS under Mangement -> Extended Events -> Sessions
-- Right-click on package0.event_file and choose "View Target Data..."
-- Search for "deadlock"
-- Highlight the xml_deadlock_report event in the grid
-- Click the "deadlock" tab in the detail view

-- Conn1 originally held an (S) lock on the table Person.Address
-- Conn2 tries to gain an (U) lock on the same table, but waiting for Conn1
-- Finally, Conn1 tries to gain an (U) lock on the same table and waiting for Conn1 
-- to release the (U) lock.  Thus deadlock occurred

-- rollback