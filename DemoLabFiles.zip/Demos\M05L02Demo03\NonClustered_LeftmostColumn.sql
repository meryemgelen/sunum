/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  
THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  
We grant You a nonexclusive, royalty-free right to use and modify the 
Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
(ii) to include a valid copyright notice on Your software product in which the Sample Code is 
embedded; and 
(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/

-- this demo gives one example where it is more efficient to put a bit column as the
-- first column in the index specifically because the range is more limited.

------------------------------------------------------- setup----------------------------------------------------------------------------------
-- run to end of setup
SET STATISTICS IO OFF;
go
SET NOCOUNT ON;
go
USE tempdb;
GO

IF EXISTS ( SELECT 1 FROM sys.objects WHERE name = 'TestBitFirst' AND type = 'U' )
    DROP TABLE TestBitFirst;
GO

CREATE TABLE TestBitFirst ( bit_col BIT NOT NULL, int_col INT NOT NULL, char_col CHAR(50) NOT NULL );

DECLARE @int_col INT = 1;
DECLARE @bit_col BIT;
WHILE @int_col < 1000
BEGIN
    SET @bit_col = @int_col % 2;

    INSERT TestBitFirst VALUES ( @bit_col, @int_col, 'value' );

    SET @int_col += 1;
END;
GO

DECLARE @counter INT = 0;

WHILE @counter < 8
BEGIN
    INSERT INTO TestBitFirst SELECT * FROM TestBitFirst;

    SET @counter = @counter + 1;
END;
GO
------------------------------------------------------- END of setup----------------------------------------------------------------------------------

-- step through this:
-- see how many rows we have:

SELECT TOP (25) * FROM dbo.TestBitFirst;
SELECT COUNT(*)FROM TestBitFirst;

-- watch the number of reads on these Queries:

SET STATISTICS IO ON;
----Use actual execution plan
-- now execute the next and look at the number of page reads required.
SELECT char_col
FROM TestBitFirst
WHERE bit_col = 1 AND int_col BETWEEN 100 AND 200;
/* Table Scan - 2031 logical reads */
---==============================
----TURN OFF - Actual execution Plan
---==============================
-- create the index with the most selective column first:
CREATE INDEX ix_Int_Bit ON TestBitFirst ( int_col, bit_col ) INCLUDE ( char_col );
GO

--create an index with the bit column (in this case, the equality column) first:
CREATE INDEX ix_Bit_Int ON TestBitFirst ( bit_col, int_col ) INCLUDE ( char_col );
GO

/*
Look at the number of page reads for each index (run together to compare side by side). 
Turn on actual execution plan and compare the subtreee costs.
*/
---Include actual execution plan to show index seek on the specified index
SELECT char_col
FROM TestBitFirst WITH (INDEX (ix_Int_Bit)) ----hint to use first int and then bit column index
WHERE bit_col = 1 AND int_col BETWEEN 100 AND 200;
/* 225 logical reads */

SELECT char_col
FROM TestBitFirst WITH ( INDEX (ix_Bit_Int) )  ----hint to use first bit  and then int column index will reduce logical read
WHERE bit_col = 1 AND int_col BETWEEN 100 AND 200;
/* 113 logical reads */

-- 225 reads for the index but only about 113 reads from the bit first index?!! Only about half of what we get 
-- when we put the more selective column first!!
-- if you hit ctrl-L and looked at estimated cost, you can see 
-- you also get a lower estimated cost with the seek with the bit column first

-- If you allow the optimizer to pick between the indexes it will still use the index ----with the bit column first.

-- and test the number of reads and the execution plan for the subtree cost:
--============================================================
---By Default sql Alsways use the index based on Left Most column in INDEX
--============================================================
SELECT char_col
FROM TestBitFirst
WHERE bit_col = 1 AND int_col BETWEEN 100 AND 200;
/* ix_Bit_Int - 113 logical reads */


-- verify the selectivity if you'd like:
SELECT DISTINCT bit_col FROM TestBitFirst; /* 2 distinct values */
SELECT DISTINCT int_col FROM TestBitFirst; /* 999 distinct values */

-- When creating an index, equality columns by selectivity should precede inequality columns by selectivity.

-- cleanup:
DROP TABLE TestBitFirst;
GO