/* single column index approach*/
/*
Production.Transactionhistory has indices on ProductID and TransactionDate.

both are high cardinality columns, so single column indexing should work well.
*/

use AdventureWorksPTO
GO

CREATE INDEX ix_TD on Production.Transactionhistory (TransactionDate)

/* check query plan (ctrl-L).  
	Two separate index seeks and a merge join, 
	total cost of query is estimated at 0.11.
*/
SELECT * 
FROM Production.TransactionHistory
WHERE ProductID = 784
		and TransactionDate = '2013-07-31 00:00:00.000'

/* if we had an index on TransactionDate, ProductID - would it help much? */
DROP INDEX ix_TD on Production.Transactionhistory
CREATE INDEX ix_TD_PID on Production.Transactionhistory (TransactionDate, ProductID)

/* check estimated plan.  subtree cost is actually higher (0.42) */
SELECT * 
FROM Production.TransactionHistory
WHERE ProductID = 784
		and TransactionDate = '2013-07-31 00:00:00.000'

DROP INDEX ix_TD_PID on Production.Transactionhistory


-----------------------------------------------------------------------------------------
/* 1 high cardinality column, 1 low cardinality column.
Both columns have indices.

SQL seeks both indices.  
Since TransactionType = 'W' represents about 25% of the table, 
that's a lot of data to bring back.  Note that the index seek 
is 29% of total cost (estimated).
*/

CREATE INDEX ix_TransactionType on Production.TransactionHistory (TransactionType)

SELECT * 
FROM Production.TransactionHistory
WHERE TransactionType = 'w'
			and ProductID = 920

DROP INDEX ix_TransactionType on Production.TransactionHistory 

/* without the index on the low cardinality field, 
SQL Server just uses the index on the high cardinality field, 
then searches that result set to filter out the other column
via the "Predicate" in the key lookup.
*/

SELECT * 
FROM Production.TransactionHistory
WHERE TransactionType = 'w'
		and ProductID = 920

/* 
SQL can do this in different ways.  
in this example using a different query, still only the high cardinality column is indexed.
SQL applies a filter operator on the high cardinality field to get the result, 
rather than filtering in the key lookup.

*/

select *
from Sales.SalesOrderDetail
where productid = 776  -- High Cardinality
		and specialOfferid = 1 -- Low Cardinality

/* 1 high cardinality column, 1 low cardinality column.
Both columns have indices.

SQL does the same thing.  maintaining the ix_specialoffer index may be worthless.
*/

CREATE INDEX ix_specialOffer on sales.salesorderdetail(specialofferid)

SELECT *
FROM Sales.SalesOrderDetail
WHERE productid = 776  -- High Cardinality
			and specialOfferid = 1 -- Low Cardinality

DROP INDEX ix_specialoffer on sales.salesorderdetail

