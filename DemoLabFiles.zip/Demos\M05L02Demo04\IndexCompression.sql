/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  
THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  
We grant You a nonexclusive, royalty-free right to use and modify the 
Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
(ii) to include a valid copyright notice on Your software product in which the Sample Code is 
embedded; and 
(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/



/* 
	this demo estimates row and page compression for all the indices in Adventureworks.
	it takes about 30 seconds to run.  progress can be tracked on the messages tab.
*/

/* 
	note that some indices (at bottom of output) either don't save space, or actually take more space if compressed
	---------------------------------------------------------------------------------------------------------------
*/

SET NOCOUNT ON;
go
USE AdventureWorksPTO;
go
IF OBJECT_ID(N'TEMPDB..#objects') IS NOT NULL DROP TABLE #objects;
IF OBJECT_ID(N'TEMPDB..#output_row') IS NOT NULL DROP TABLE #output_row;
IF OBJECT_ID(N'TEMPDB..#output_page') IS NOT NULL DROP TABLE #output_page;
GO

CREATE TABLE #objects (
    id INT IDENTITY(1, 1),
    schema_name NVARCHAR(128),
    table_name NVARCHAR(128)
);

CREATE TABLE #output_row (
    table_name sysname COLLATE DATABASE_DEFAULT,
    schema_name sysname COLLATE DATABASE_DEFAULT,
    index_id INT,
    partition_number INT,
    size_with_current_kb BIGINT,
    size_with_requested_compression_kb BIGINT,
    sample_size_with_current_kb BIGINT,
    sample_size_with_requested BIGINT
);

CREATE TABLE #output_page (
    table_name sysname COLLATE DATABASE_DEFAULT,
    schema_name sysname COLLATE DATABASE_DEFAULT,
    index_id INT,
    partition_number INT,
    size_with_current_kb BIGINT,
    size_with_requested_compression_kb BIGINT,
    sample_size_with_current_kb BIGINT,
    sample_size_with_requested BIGINT
);

-----------------------------------------------------------------

INSERT INTO #objects
SELECT 
	DISTINCT s.name AS schema_name, 
	o.name AS table_name
FROM 
	sys.schemas s
	JOIN sys.objects o 
		ON o.schema_id = s.schema_id
WHERE 
	o.type IN ('u', 'v') 
	AND
	EXISTS ( SELECT * FROM sys.indexes i WHERE i.object_id = o.object_id ) 
	AND
	s.name <> 'Graph' -- skip tables on graph schema due 
	AND
	NOT EXISTS ( SELECT *
                   FROM sys.columns c
                   WHERE c.object_id = o.object_id AND c.encryption_algorithm_name IS NOT NULL )
GO

SELECT * FROM #objects;

DECLARE @schema_name sysname = '';
DECLARE @table_name sysname = '';
DECLARE @counter INT = 1;
DECLARE @max_counter INT = ( SELECT COUNT(*)FROM #objects );

WHILE @counter <= @max_counter
BEGIN
    SELECT @schema_name = schema_name, @table_name = table_name
    FROM #objects
    WHERE id = @counter;

    INSERT INTO #output_row
    EXEC sp_estimate_data_compression_savings @schema_name, @table_name, NULL, NULL, 'row';

    INSERT INTO #output_page
    EXEC sp_estimate_data_compression_savings @schema_name, @table_name, NULL, NULL, 'page';

    RAISERROR('%d of %d - %s ', 10, 1, @counter, @max_counter, @table_name) WITH NOWAIT;

    SET @counter += 1;
END;
GO

-------------------------------------------------------------------

/* review index-specific data.  
page compression recommended if page compression has at least a 10% savings, and saves at least 5% more than row.
row compression recommended if row compressino saves at least 10%, and is less than 5% below page.
*/

IF OBJECT_ID(N'TEMPDB..#results') IS NOT NULL DROP TABLE #results;

SELECT r.table_name, r.schema_name, r.index_id, r.partition_number,
    r.size_with_current_kb AS current_size_kb, r.size_with_requested_compression_kb AS row_size_kb,
    p.size_with_requested_compression_kb AS page_size_kb,
    CAST(100 - ( r.size_with_requested_compression_kb * 100.0 / r.size_with_current_kb ) AS DECIMAL(12, 2)) AS row_compression_pct,
    CAST(100 - ( p.size_with_requested_compression_kb * 100.0 / p.size_with_current_kb ) AS DECIMAL(12, 2)) AS page_compression_pct,
    CASE WHEN CAST(100 - ( p.size_with_requested_compression_kb * 100.0 / p.size_with_current_kb ) AS DECIMAL(12, 2))
              - CAST(100
                     - ( r.size_with_requested_compression_kb * 100.0 / r.size_with_current_kb ) AS DECIMAL(12, 2)) > 5 AND
              CAST(100 - ( p.size_with_requested_compression_kb * 100.0 / p.size_with_current_kb ) AS DECIMAL(12, 2)) > 10 THEN
             'page compress'
    WHEN CAST(100 - ( p.size_with_requested_compression_kb * 100.0 / p.size_with_current_kb ) AS DECIMAL(12, 2))
         - CAST(100 - ( r.size_with_requested_compression_kb * 100.0 / r.size_with_current_kb ) AS DECIMAL(12, 2)) < 5 AND
         CAST(100 - ( r.size_with_requested_compression_kb * 100.0 / r.size_with_current_kb ) AS DECIMAL(12, 2)) > 10 THEN
        'row compress' ELSE 'do not compress' END AS recommended_compression,
    r.size_with_current_kb - r.size_with_requested_compression_kb AS row_space_saved_kb,
    p.size_with_current_kb - p.size_with_requested_compression_kb AS page_space_saved_kb
INTO #results
FROM #output_row r
     JOIN #output_page p ON p.schema_name = r.schema_name AND p.table_name = r.table_name AND
                            p.index_id = r.index_id AND p.partition_number = r.partition_number
WHERE r.size_with_current_kb > 64; -- don't bother if only 1 extent.

SELECT recommended_compression,
    SUM(CAST(current_size_kb / 1024.0 AS DECIMAL(38, 2))) AS current_mb,
    SUM(CASE WHEN recommended_compression = 'row compress' THEN
                 CAST(row_space_saved_kb / 1024.0 AS DECIMAL(38, 2))
        WHEN recommended_compression = 'page compress' THEN
            CAST(page_space_saved_kb / 1024.0 AS DECIMAL(38, 2))ELSE 0 END) AS space_saved_mb
FROM #results
GROUP BY recommended_compression;

SELECT * FROM #results ORDER BY page_compression_pct DESC;

SELECT * FROM #results WHERE table_name = N'Person';

/*****************************************************************************/

-- Clean up 
DROP TABLE #objects;
DROP TABLE #output_page;
DROP TABLE #output_row;
DROP TABLE #results;
GO