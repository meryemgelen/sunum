/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  
THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  
We grant You a nonexclusive, royalty-free right to use and modify the 
Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
(ii) to include a valid copyright notice on Your software product in which the Sample Code is 
embedded; and 
(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/

SET NOCOUNT ON;
go
USE AdventureWorksPTO;
GO

/*
	this query shows the indexes for table Sales.SalesOrderHeader
	notice that not all indexes have been used for SEEK/SCAN
	maybe the CLUSTER index hasn't been used for LOOKUP yet

	copy this query to another session that runs in a separate vertical tab

*/
USE AdventureWorksPTO
GO
SELECT 
    i.index_id,
	indexname = i.name, 
    user_seeks, user_scans, user_lookups, user_updates,
    user_seeks + user_scans + user_lookups AS total_reads
FROM 
	sys.dm_db_index_usage_stats s
    RIGHT OUTER JOIN sys.indexes i 
		ON i.object_id = s.object_id AND i.index_id = s.index_id
    JOIN sys.objects o 
		ON o.object_id = i.object_id
    JOIN sys.schemas sc 
		ON sc.schema_id = o.schema_id
WHERE o.type = 'U' -- user table
    AND o.name = N'SalesOrderHeader';
GO
----------------------------------------------------------------------------------------------------------------------
	--	the following queries will be executed one by one, and after
	--	each query, execute the ABOVE QUERY ON THE OTHER VERTICAL TAB
	--	to check which index was used and the corresponding operation
------------------------------------------------------------------------------------------------------------------------
SELECT * 
FROM Sales.SalesOrderHeader 
WHERE SalesOrderID=43800
-- execute query on 2nd session
-- >> check increase for USER_Seeks on PK_SalesOrderHeader_SalesOrderID
SELECT * 
FROM Sales.SalesOrderHeader 
WHERE SalesOrderNumber='SO43800'
-- execute query on 2nd session
-- >> check increase for USER_Seeks on AK_SalesOrderHeader_SalesOrderNumber
-- >> >> and increase for Lookup on PK_SalesOrderHeader_SalesOrderID

SELECT SalesOrderID, SalesOrderNumber
FROM Sales.SalesOrderHeader 
WHERE SalesOrderNumber='SO43800'
-- execute query on 2nd session
-- >> check increase for USER_Seeks on AK_SalesOrderHeader_SalesOrderNumber
-- >> >> and NO increase for Lookup on PK_SalesOrderHeader_SalesOrderID

SELECT SalesOrderID
FROM Sales.SalesOrderHeader 
WHERE AccountNumber	= '10-4030-021710'
-- execute query on 2nd session
-- >> check increase for USER_Seeks on SalesOrderHeader_Account
-- >> >> and NO increase for Lookup on PK_SalesOrderHeader_SalesOrderID


SELECT *
FROM Sales.SalesOrderHeader 
WHERE AccountNumber	= '10-4030-021710'
-- execute query on 2nd session
-- >> check increase for USER_Seeks on SalesOrderHeader_Account
-- >> >> and increase for Lookup on PK_SalesOrderHeader_SalesOrderID



SELECT *
FROM Sales.SalesOrderHeader 
WHERE CustomerID=21710
-- execute query on 2nd session
-- >> check increase for USER_Seeks on AK_SalesOrderHeader_SalesOrderNumber
-- >> >> and increase for Lookup on PK_SalesOrderHeader_SalesOrderID

Declare @RowGuid as UNIQUEIDENTIFIER  = '46CD4997-1031-482B-8EAB-4F1FECCCBEE1'
UPDATE Sales.SalesOrderHeader
SET ModifiedDate = getdate()
WHERE rowguid = @RowGuid
-- execute query on 2nd session
-- >> check increase for USER_Seeks on AK_SalesOrderHeader_rowguid
-- >> >> and increase for user_updates on PK_SalesOrderHeader_SalesOrderID

SELECT *
FROM Sales.SalesOrderHeader 
WHERE RevisionNumber=8
-- execute query on 2nd session
-- >> check increase for USER_Scans on PK_SalesOrderHeader_SalesOrderID

SELECT SalesPersonID, COUNT(*)
FROM Sales.SalesOrderHeader 
GROUP BY SalesPersonID
-- execute query on 2nd session
-- >> check increase for USER_Scans on IX_SalesOrderHeader_SalesPersonID



SELECT *
FROM Sales.SalesOrderHeader 
WHERE SalesPersonID=285
-- execute query on 2nd session
-- >> check increase for USER_Seeks on IX_SalesOrderHeader_SalesPersonID
-- >>   and increase for USER_lookups on PK_SalesOrderHeader_SalesOrderID

-- what about a delete statement?
DELETE Sales.SalesOrderHeader 
WHERE SalesPersonID=285
-->> what does it change 

-- CLOSE THE 2nd TAB.

-- ************************************************
-- looking for rarely used indices on all tables -- 
-- ************************************************
-- >> NOTICE that this query doesn't show all indexes existing on the database.
--    WHY?
--    if the index hasn't been used so far, it does not have an entry in the sys.dm_db_index_usage_stats s
--    as the query doesn't use an outer join.. they don't show up
SELECT 
	s.object_id, indexname = i.name, 
    user_seeks, user_scans, user_lookups, user_updates,
    user_seeks + user_scans + user_lookups AS total_reads
FROM 
	sys.dm_db_index_usage_stats s
    JOIN sys.indexes i 
		ON i.object_id = s.object_id AND i.index_id = s.index_id
    JOIN sys.objects o 
		ON o.object_id = i.object_id
    JOIN sys.schemas sc 
		ON sc.schema_id = o.schema_id
WHERE 
	o.type = 'U' -- user table
    AND 
	user_seeks + user_scans + user_lookups < 20
ORDER BY ( user_seeks + user_scans + user_lookups );
--------------------------------------------------------------------------------------------------------------
--									OPTIONAL DEMO
--				Adding a new index and querying on that new index
--                     find nonclustered indices with high scan rates
--                  create some data by using an implicit conversion 
------------------------------------------------------------------------------------------------------------------
CREATE INDEX ix_cc ON Sales.SalesOrderHeader ( CreditCardApprovalCode );
GO

SELECT *
FROM Sales.SalesOrderHeader
WHERE CreditCardApprovalCode = '128163Vi17021';
GO 25

/* see that the index is scanned, not seeked.  that's a good sign that
something may need to be fixed, though if it were a multi-column index it 
could be from queries filtering on columns other than the first one. */

SELECT sc.name AS schema_name, o.name AS object_name, s.object_id, indexname = i.name, i.index_id,
    user_seeks, user_scans, user_lookups, user_updates,
    user_seeks + user_scans + user_lookups AS total_reads
FROM sys.dm_db_index_usage_stats s
     JOIN sys.indexes i ON i.object_id = s.object_id AND i.index_id = s.index_id
     JOIN sys.objects o ON o.object_id = i.object_id
     JOIN sys.schemas sc ON sc.schema_id = o.schema_id
WHERE o.type = 'U' -- user table
    AND o.name = N'SalesOrderHeader';
GO

-- Clean up 
DROP INDEX ix_cc ON Sales.SalesOrderHeader;
GO
	