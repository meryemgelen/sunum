/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  
THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  
We grant You a nonexclusive, royalty-free right to use and modify the 
Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
(ii) to include a valid copyright notice on Your software product in which the Sample Code is 
embedded; and 
(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/

-- review missing index recommendations 
-- important things to note:  
--   typically, a few indices are much more impactful than the rest
--   you may be able to consolidate recommendations (note indexes on Status, and on Status, PurchaseOrderNumber)
--   pay attention to cardinality.  would purchaseOrderNumber, Status be better than Status, PO#?  would consolidate with PO#
--   , which has a higher total cost.  if status has low cardinality, may be good choice to scan the PO, status index.

SET NOCOUNT ON;
GO
USE AdventureWorksPTO;
GO
SELECT  
	'Missing indices' AS Output_Type, 
	SCHEMA_NAME(t.schema_id) AS [schema],
	t.name 'table', 
    total_cost_savings = 
		ROUND( s.avg_total_user_cost * s.avg_user_impact * ( s.user_seeks + s.user_scans ), 0) / 100, 
	s.avg_total_user_cost,
    s.avg_user_impact, 
	( avg_total_user_cost * avg_user_impact ) * ( user_seeks + user_scans ) AS 'impact',
	s.user_seeks, 
	s.user_scans, 
	unique_compiles, 
	last_user_seek, 
	last_user_scan, 
	d.equality_columns,
    d.inequality_columns, 
	d.included_columns,
	'CREATE NONCLUSTERED INDEX ix_IndexName ON '  
		+ SCHEMA_NAME(t.schema_id)
        + '.' + t.name COLLATE DATABASE_DEFAULT 
		+ ' ('
        + ISNULL(d.equality_columns, '')
        + CASE 
			WHEN d.inequality_columns IS NULL THEN ''
			ELSE 
				CASE 
					WHEN d.equality_columns IS NULL THEN ''
					ELSE ','
				END + d.inequality_columns
		  END + ') ' 
		+ CASE 
			WHEN d.included_columns IS NULL THEN ''
			ELSE 'INCLUDE (' + d.included_columns + ')'
		END + ';' AS 'create_index_statement'
FROM    
	sys.dm_db_missing_index_group_stats AS s
	INNER JOIN sys.dm_db_missing_index_groups AS g 
		ON s.group_handle = g.index_group_handle
	INNER JOIN sys.dm_db_missing_index_details AS d 
		ON g.index_handle = d.index_handle 
	INNER JOIN sys.tables t WITH ( NOLOCK ) 
		ON d.OBJECT_ID = t.OBJECT_ID
WHERE   
	d.database_id = DB_ID() 
	AND
	s.group_handle IN ( 
		SELECT TOP 500 group_handle
		FROM  sys.dm_db_missing_index_group_stats WITH ( NOLOCK )
		ORDER BY ( avg_total_user_cost * avg_user_impact ) * ( user_seeks + user_scans ) DESC 
	) 
	AND 
	(
	/* Optionally filter by table */
		t.object_id = object_id('Person.Person')		
		OR
		t.object_id = object_id('Sales.SalesOrderHeader')		
	)
ORDER BY 
	( avg_total_user_cost * avg_user_impact ) * ( user_seeks + user_scans ) DESC
OPTION	(RECOMPILE);
GO


-- execute a query that will populate the Missing Index DMVs
-- IF TIME ALLOWS, EXECUTE THE QUERY BELOW 1 TIME WITH THE ACTUAL EXECUTION PLAN
--	>> SHOW SCAN
--	>> Show QUERY COST
SELECT COUNT(*) FROM Person.Person WHERE PersonType = 'em';
GO 10
-- EXECUTE the query on 2nd tab:
-- CHECK: entry for Equality_column = '[PersonType]'
-- review the value on columns: 
--				avg_total_user_cost = 2.85726603055155 
--										** notice this value is the same as the cost on the EXECUTION PLAN
--				avg_user_impact = 99.73
--										** notice: this is a calculated formula
-- get the value on column: create_index_statement
------------------------------------Create Missing Index--------------------------------------------------------
CREATE NONCLUSTERED INDEX IX_PersonType ON Person.Person ([PersonType]) ;
-- implement the CREATE INDEX above

/*
	the drop index command is available below in case 
	the part of the demo before INDEX creation is needed
*/
--		DROP INDEX IX_PersonType ON Person.Person ;
--------------------------------------------------------------------------------------------------------------------------
-- now repeat the query above to compare new cost
SELECT COUNT(*) 
FROM Person.Person 
	WHERE PersonType = 'em';

-- new query cost = 0.0037466
-- gain calculation = 
SELECT (2.85726 - 0.0037466) / 2.85726 -- 0.9986 = 99.86%
-- compare the calculated value with the avg_user_impact obtained above


------------------------------------------------------------ 
--------Optional Examples--------------------------- 
-------------------------------------------------------------
-- the examples below provide similar output               --
-- ------------------------------------------------------- --
-- >> OPTIONAL                                             <<
-- >> for every query below, you can also                  <<
-- >> display information that can be                      <<
-- >> retrieved from QUERY CACHE by using                  <<
-- >> script:                                              <<
-- >> [Lesson 04 - 2 - missing index from Query Cache.sql] <<
-- ------------------------------------------------------- --
SELECT COUNT(*)
FROM Person.Person
WHERE modifieddate = '2009-01-07 00:00:00.000';
GO 50
-- execute the query on 2nd tab:
-- CHECK: entry for equality_column = '[ModifiedDate]'

SELECT COUNT(*) FROM Sales.SalesOrderHeader WHERE Status = 5;
GO 20 
-- edit the query on 2nd tab to table 'SalesOrderHeader'
-- execute the query on 2nd tab:
-- CHECK: entry for equality_column = '[Status]'

SELECT COUNT(*) FROM Sales.SalesOrderHeader WHERE Status <> 5;
GO 15
-- execute the query on 2nd tab:
-- CHECK: entry for inequality_column = '[Status]'

SELECT *
FROM Sales.SalesOrderHeader
WHERE Status = 5 AND PurchaseOrderNumber = 'PO18850127500';
GO 16
-- execute the query on 2nd tab:
-- CHECK: entry for equality_column = '[Status], [PurchaseOrderNumber]'

SELECT *
FROM Sales.SalesOrderHeader
WHERE PurchaseOrderNumber = 'PO18850127500';
GO 50 
-- execute the query on 2nd tab:
-- CHECK: entry for equality_column = '[PurchaseOrderNumber]'

-- ASK Participants:
--> does it make sense to create the 2 indexes?
-->		[Status], [PurchaseOrderNumber]
-->		[PurchaseOrderNumber]




