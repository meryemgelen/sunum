/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  
THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  
We grant You a nonexclusive, royalty-free right to use and modify the 
Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
(ii) to include a valid copyright notice on Your software product in which the Sample Code is 
embedded; and 
(iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/

use Master
go
Create Database MLPTest
go 
Use  MLPTest
go
------Create Partition Function
CREATE PARTITION FUNCTION PartFunc1 (float) 
AS RANGE RIGHT FOR VALUES (100,200,300,400,500,600,700)
GO
--Create partition scheme

CREATE PARTITION SCHEME PartSch1
AS PARTITION PartFunc1
ALL TO ([PRIMARY])
GO
-----Create Partition Table
Create Table OnlineIndexRebuild
(
col1 float,
col2 varchar(20),
col3 datetime
)On PartSch1(col1)

--- insert records into the table
TRUNCATE table OnlineIndexRebuild
Set NoCount on
DECLARE @count float = 0.1
while @count <= 800
begin
		Insert into OnlineIndexRebuild values (@count, 'Person'+cast(@count as varchar(5)), getdate())
		set @count += 0.1
end 
-----Show the no of rows Added to Each Partition
-- select * from sys.partitions where object_id = object_id ('OnlineIndexRebuild')
--------------------------
--- Create an Index 
Create clustered Index Clus1 on OnlineIndexRebuild(Col1)
On PartSch1(col1)

--- Alter Index online for some partitions. 
--If using SQL 2012 this would have given an Error
Alter Index Clus1 on OnlineIndexRebuild
Rebuild Partition=2
With (Online = ON)
--========================================================
-- Step 2 -- Behaviour without Managed Lock Priotity
--===========================
--- Open a new Query Window and run the following Commands
--========================================================
Set Transaction Isolation Level Repeatable Read 
-- this would ensure the locks are held on rows which are getting read until transaction is not completed
Begin Tran
	Select top 1 * from OnlineIndexRebuild where col1 = 0.1
-- Rollback

--===========come back to this session after starting above transaction in another window==========
--- Run the following command from the current window
--- This command should get blocked (default behavior)
--=================================================================================
Alter Index Clus1 on OnlineIndexRebuild
Rebuild Partition=1
With (Online = ON)
-----To show Blocking open a new window and run Select * from Sys.sysprocesses where blocked >0

---=================================================================================================
---if you don't want to use extended event then show in Error log(sp_readerrorlog) if blocker or self session was KILLED by MLP
----=================================================================================================
--- Rollback the select transaction which was run from the second window.
-- Create a Extented Event Session to monitor Online Index Rebuild
--drop event session spoir_session on server
--Create Extended Event Session for OIR (online index rebuild)
DROP EVENT SESSION spoir_session ON SERVER
GO
xp_cmdshell 'del "C:\temp\XEvents\SPOIR*.xel"'
go
CREATE EVENT SESSION spoir_session
ON SERVER
    ADD EVENT sqlserver.progress_report_online_index_operation (ACTION(sqlserver.session_id)) ,
	ADD EVENT sqlserver.lock_request_priority_state(ACTION(sqlserver.session_id)) ,
    ADD EVENT sqlserver.process_killed_by_abort_blockers(ACTION(sqlserver.session_id)) ,
    ADD EVENT sqlserver.ddl_with_wait_at_low_priority(ACTION(sqlserver.session_id)) 
    ADD TARGET event_file
(set filename=N'C:\temp\XEvents\SPOIR.xel')
GO
ALTER EVENT SESSION spoir_session on server state=start
go

--- Watch Live data from the Extended Event Session
--========================================================
-- Step 3 -- Behaviour with Managed Lock Priotity
--===========================
--- Open a new Query Window and run the following Commands
--========================================================
--- Run the following command from a different query window
Set Transaction Isolation Level Repeatable Read -- this would ensure the locks are held.
Begin Tran
	Select top 1 * from OnlineIndexRebuild where col1 = 0.1
-- Rollback
--===========come back to this session after starting above transaction in another window==========
--- Run the following command from the current window
--- This command should get blocked (default behavior)
--=================================================================================
--- Execute the following command from the current window.. 
--- Notice the new SYNTAX WAIT_AT_LOW_PRIORITY and 
--- Rebuild partition 1 online using managed lock priority

Alter Index Clus1 on OnlineIndexRebuild
Rebuild Partition=1
WITH (ONLINE = ON (WAIT_AT_LOW_PRIORITY (MAX_DURATION= 1, ABORT_AFTER_WAIT=BLOCKERS)));
--WITH (ONLINE = ON (WAIT_AT_LOW_PRIORITY (MAX_DURATION= 1, ABORT_AFTER_WAIT=SELF)));
--=========================================================
-- After one min, this Alter Index Rebuild command complete successfully.
---========================================================
-- check the other query window.. try committing or rolling back the tranaction. 
--	--> It should fail saying that the connection has been closed.
--
---===================================
-- Check the SQl Error Logs
Exec sp_readerrorlog
--====================================
/*
An 'ALTER INDEX REBUILD' statement was executed on object 'OnlineIndexRebuild' by hostname 'localhost', host process ID 33256 using the WAIT_AT_LOW_PRIORITY options with MAX_DURATION = 1 and ABORT_AFTER_WAIT = BLOCKERS. Blocking user sessions will be killed after the max duration of waiting time.
An ABORT_AFTER_WAIT = BLOCKERS lock request was issued on database_id = 10, object_id = 293576084. All blocking user sessions will be killed.
Process ID 53 was killed by an ABORT_AFTER_WAIT = BLOCKERS DDL statement on database_id = 10, object_id = 293576084.
*/

-- the other option is Abort_After_Wait = SELF, will terminate the current Alter Index Request.


-- IF TIME ALLOWS:
-- open the XEL file via SSMS and show the events
-- OR
-- execute query below to display data collected with XEvents is available
SELECT 
	event_data = CONVERT(XML, event_data) 
--  INTO #t
FROM 
	sys.fn_xe_file_target_read_file(N'E:\SQL2017\XEvents\SPOIR*.xel', NULL, NULL, NULL);

-------Cleanup
Use Master
go
-- stop and drop XEvent session
ALTER EVENT SESSION spoir_session on server state=stop
go
DROP EVENT SESSION [spoir_session] ON SERVER 
GO
Drop Database MLPTest


