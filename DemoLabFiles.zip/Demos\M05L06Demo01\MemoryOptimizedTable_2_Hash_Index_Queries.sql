/* 
This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment. THIS SAMPLE CODE AND ANY RELATED INFORMATION 
	ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
	INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
	FOR A PARTICULAR PURPOSE. 
We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided 
	that You agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in 
		which the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product in which the Sample 
		Code is embedded; and 
	(iii) to indemnify, hold harmless, and defend Us and our suppliers from and against 
		any claims or lawsuits, including attorneys fees, that arise or result from the 
		use or distribution of the Sample Code.
*/
USE MemoryOptimizedDB
GO

-- turn on EXECUTION PLAN
-- evaluate how the table gets accessed according to the PREDICATE and EXISTING INDEXES
SET STATISTICS IO ON
SET STATISTICS TIME ON
SET STATISTICS PROFILE ON 
-- ALTERNATIVELY TURN ON QUERY STORE (script: )

-- SEEK & SCAN: PK_Product____
SELECT * 
FROM [Product_Workload] 
WHERE ProductID = 123 -- HASH INDEX on [ProductID]  --> SEEK operation

SELECT * 
FROM [Product_Workload] 
WHERE ProductID < 123 -- HASH INDEX on [ProductID]  --> SCAN operation 

SELECT * 
FROM Product_Workload
WHERE ProductID BETWEEN 123 and 125 -- HASH INDEX on [ProductID]  --> SCAN operation 

SELECT * 
FROM Product_Workload
WHERE ProductID IN (123, 124, 125) -- HASH INDEX on [ProductID]  --> SEEK operation

SELECT ProductID, Name 
FROM Product_Workload 
WHERE ProductID IN (123, 124, 125)
ORDER BY ProductID  -- HASH INDEX on [ProductID]  --> SEEK operation + SORT: HASH INDEX cannot be used for ORDERING

SELECT * FROM 
(SELECT * 
FROM Product_Workload
WHERE ProductID IN (123, 124, 125)) as ABC
ORDER BY 
	PRODUCTID  -- HASH INDEX on [ProductID]  --> SEEK operation + SORT: HASH INDEX cannot be used for ORDERING


SELECT * 
FROM Product_Workload
WHERE ProductID NOT IN (
	123, 124, 125
)  -- HASH INDEX on [ProductID]  --> SCAN operation 

SELECT AVG(ReorderPoint), SUM(SafetyStockLevel)
FROM Product_Workload
WHERE ProductID IN (123, 124, 125) -- HASH INDEX on [ProductID]  --> SEEK operation + aggregate


-- SEEK & SCAN on COMPOSITE HASH INDEX: HIX_ProductNumberColor
SELECT *
FROM Product_Workload
WHERE 
	ProductNumber = 'BK-R64Y-42A'
 -- HASH INDEX HIX_ProductNumberColor on (ProductNumber,Color)
 --> SCAN operation: seek only works if full key is provided

SELECT *
FROM Product_Workload
WHERE 
	ProductNumber = 'BK-R64Y-42A'
	AND
	Color IS NULL
 -- HASH INDEX HIX_ProductNumberColor on (ProductNumber,Color)
 --> SEEK operation: full key has been provided

SELECT *
FROM Product_Workload
WHERE 
	ProductNumber = 'BK-R64Y-42A'
	AND
	Color IS NOT  NULL
 -- HASH INDEX HIX_ProductNumberColor on (ProductNumber,Color)
 --> SCAN operation: full key hasn't been provided

SELECT COUNT(*)
FROM Product_Workload
WHERE 
	ProductNumber = 'BK-R64Y-42A'
 -- HASH INDEX HIX_ProductNumberColor on (ProductNumber,Color)
 --> SCAN operation: full key hasn't been provided

SELECT Color, COUNT(*)
FROM Product_Workload
WHERE 
	ProductNumber = 'BK-R64Y-42A'
GROUP BY
	Color
 -- HASH INDEX HIX_ProductNumberColor on (ProductNumber,Color)
 --> SCAN operation: full key hasn't been provided

SELECT Color, COUNT(*)
FROM Product_Workload
WHERE 
	ProductNumber = 'BK-R64Y-42A'
	AND
	Color IN ('Black',
				'Blue',
				'Grey')
GROUP BY
	Color
 -- HASH INDEX HIX_ProductNumberColor on (ProductNumber,Color)
 --> SEEK + SORT operation: full key has been provided
 --> + SORT operation: HASH INDEX does not provide ordering


SELECT COUNT(*) 
FROM Product_Workload
WHERE 
	ProductNumber LIKE 'BK-R64Y%'
	AND
	Color IS NULL
 -- HASH INDEX HIX_ProductNumberColor on (ProductNumber,Color)
 --> SCAN operation: HASH index does not work with LIKE

--  
SELECT ReorderPoint, COUNT(*)
FROM Product_Workload
WHERE 
	ProductNumber = 'BK-R64Y-42A'
	AND
	Color IN ('Black', 'Blue', 'Grey')
GROUP BY
	ReorderPoint
 -- HASH INDEX HIX_ProductNumberColor on (ProductNumber,Color)
 --> SEEK operation: full key has been provided
 --> + SORT + STREAM AGGREGATE operation

