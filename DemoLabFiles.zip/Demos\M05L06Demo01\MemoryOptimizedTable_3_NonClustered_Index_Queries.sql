/* 
This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment. THIS SAMPLE CODE AND ANY RELATED INFORMATION 
	ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
	INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
	FOR A PARTICULAR PURPOSE. 
We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided 
	that You agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in 
		which the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product in which the Sample 
		Code is embedded; and 
	(iii) to indemnify, hold harmless, and defend Us and our suppliers from and against 
		any claims or lawsuits, including attorneys fees, that arise or result from the 
		use or distribution of the Sample Code.
*/
USE MemoryOptimizedDB
GO

-- turn on EXECUTION PLAN
-- Evaluate how the table gets accessed according to the PREDICATE and EXISTING INDEXES
SET STATISTICS IO ON
SET STATISTICS TIME ON
SET STATISTICS PROFILE ON 

-- SEEK & SCAN: NIX_Name
SELECT * 
FROM [Product_Workload] 
WHERE Name = 'LL Road Frame - Black, 60'

SELECT * 
FROM [Product_Workload] 
WHERE Name <> 'LL Road Frame - Black, 60'

SELECT * 
FROM [Product_Workload] 
WHERE 
	Name BETWEEN 'LL Road Frame - Black, 60' 
	AND 'LL Road Frame - Black, 80'
--> SEEK: NonClustered Index works same way for Memory-Optimized tables as for Disk-Based Tables

	
SELECT * 
FROM Product_Workload
WHERE Name IN (
	'LL Road Frame - Black, 60',
	'LL Road Frame - Black, 62',
	'LL Road Frame - Black, 80'
	)

SELECT * 
FROM Product_Workload
WHERE Name NOT IN (
	'LL Road Frame - Black, 60',
	'LL Road Frame - Black, 62',
	'LL Road Frame - Black, 80'
	)


SELECT * 
FROM Product_Workload
WHERE ProductNumber IN (
	'FR-R38B-58O',
	'FR-R38B-60O',
	'FR-R38B-62O'
	)
ORDER BY Name 
--> uses TABLE SCAN as ProductNumber is not the full HASH KEY
--> + SORT to provide order by name

SELECT *
FROM Product_Workload
WHERE ProductId IN (125146,125148,125147)
ORDER BY Name
--> uses SEEK as ProductID is the full HASH KEY
--> + SORT to provide order by name

SELECT * 
FROM [Product_Workload] 
WHERE Name <= 'Decal 1'
ORDER BY NAME
--> uses SEEK as Name is a NonClustered Index, with same behavior as Disk-Based table
--> NO SORT is used: same behavior as NonClustered index for Disk-Based table

SELECT * 
FROM [Product_Workload] 
WHERE Name <= 'Decal 1'
ORDER BY NAME ASC
--> uses SEEK as Name is a NonClustered Index, with same behavior as Disk-Based table
--> NO SORT is used: same behavior as NonClustered index for Disk-Based table

SELECT * 
FROM [Product_Workload] 
WHERE Name <= 'Decal 1'
ORDER BY NAME DESC
--> uses SEEK as Name is a NonClustered Index, with same behavior as Disk-Based table
--> SORT needed: index was created ASC, query is asking for DESC order

SELECT * 
FROM [Product_Workload] 
WHERE Name 
	BETWEEN 'Decal 1'
	AND 'Decal 9'
	AND
	Color = 'Grey'
--> uses SEEK as Name is a NonClustered Index, with same behavior as Disk-Based table
--> FILTER: filter by color

SELECT * 
FROM [Product_Workload] 
WHERE Name LIKE 'Decal%'
--> uses SEEK as Name is a NonClustered Index, with same behavior as Disk-Based table
--> FILTER 

SELECT * 
FROM [Product_Workload] 
WHERE Name LIKE '%Decal%'
--> uses SCAN as Name is a NonClustered Index. LIKE with leading % results in SCAN


-- NonClustered Index NIX_ClassSize. Composite Key on 
-- [Class] ASC, [Size] ASC


SELECT *
FROM Product_Workload
WHERE 
	Class = 'M'
--> uses SEEK as Class+Size  is a NonClustered Index, with same behavior as Disk-Based table

SELECT *
FROM Product_Workload
WHERE 
	Class = 'M'
ORDER BY Class, Size 
--> uses SEEK as Class+Size  is a NonClustered Index, with same behavior as Disk-Based table
--> no need to use SORT

SELECT *
FROM Product_Workload
WHERE 
	Class = 'M'
ORDER BY Class, Size DESC
--> uses SEEK as Class+Size  is a NonClustered Index, with same behavior as Disk-Based table
--> use SORT as the order by is SIZE DESC


SELECT *
FROM Product_Workload
WHERE 
	Class = 'M'
	AND
	Size <> '44'
--> uses SEEK as Class+Size  is a NonClustered Index, with same behavior as Disk-Based table

SELECT *
FROM Product_Workload
WHERE 
	Class = 'M'
	AND
	Size <> '44'
ORDER BY Class, Size
--> uses SEEK as Class+Size  is a NonClustered Index, with same behavior as Disk-Based table


SELECT Size, COUNT(*)
FROM Product_Workload
WHERE 
	Class = 'L'
GROUP BY Class, Size
--> uses SEEK as Class+Size  is a NonClustered Index, with same behavior as Disk-Based table
--> STREM AGGREGATE

SELECT Class, COUNT(*)
FROM Product_Workload
WHERE 
	Size IN ('40','42','44')
GROUP BY Class, Size
--> uses SCAN as Class+Size is a NonClustered Index, with same behavior as Disk-Based table
--> WHERE clause does not provide LEFTMOST column: index cannot be used for SEEK
--> STREM AGGREGATE


SELECT *
FROM Product_Workload
WHERE 
	Size IN ('40','42','44')
--> uses SCAN as Class+Size is a NonClustered Index, with same behavior as Disk-Based table
--> WHERE clause does not provide LEFTMOST column: index cannot be used for SEEK


-- clean-up tables
DROP TABLE IF EXISTS [Product_Workload]
