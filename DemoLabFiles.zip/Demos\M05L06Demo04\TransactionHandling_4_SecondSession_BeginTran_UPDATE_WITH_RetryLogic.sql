-- Transactions with Memory-Optimized Tables
-- https://msdn.microsoft.com/en-us/library/mt668435.aspx

/* 
This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment. THIS SAMPLE CODE AND ANY RELATED INFORMATION 
	ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
	INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
	FOR A PARTICULAR PURPOSE. 
We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided 
	that You agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in 
		which the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product in which the Sample 
		Code is embedded; and 
	(iii) to indemnify, hold harmless, and defend Us and our suppliers from and against 
		any claims or lawsuits, including attorneys fees, that arise or result from the 
		use or distribution of the Sample Code.
*/
USE MemoryOptimizedDB
GO

SELECT transaction_isolation_level,Open_transaction_count, * 
FROM sys.dm_exec_sessions
WHERE Open_transaction_count>0 
OR session_id = @@SPID

SELECT 
	MakeFlag,
	*
FROM
	[Product]
WHERE	
	ProductID = 904



---- RETRY LOGIC
declare @retry_count int = 0
WHILE (@retry_count >= 0 AND @retry_count <4)
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			UPDATE [Product] WITH (SNAPSHOT)
			SET		Name = 'update me'
			WHERE	ProductID = 904
			SET @retry_count = -1
		COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		SELECT  
			@retry_count as Retry_Count,
			ERROR_NUMBER() AS [Error Number],
			ERROR_MESSAGE() AS [ErrorMessage];     
  		SET @retry_count += 1
		WAITFOR DELAY '00:00:05'
	END CATCH
END

IF @retry_count = -1
	SELECT 'UPDATE DONE' as STATUS,MakeFlag,*
	FROM	[Product]
	WHERE	ProductID = 904
ELSE
	SELECT 'UPDATE FAILED' as STATUS
