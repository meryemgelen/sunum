/* 
This Sample Code is provided for the purpose of illustration only and is not intended
	to be used in a production environment. THIS SAMPLE CODE AND ANY RELATED INFORMATION 
	ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
	INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
	FOR A PARTICULAR PURPOSE. 
We grant You a nonexclusive, royalty-free right to use and modify the Sample Code
	and to reproduce and distribute the object code form of the Sample Code, provided 
	that You agree: 
	(i) to not use Our name, logo, or trademarks to market Your software product in 
		which the Sample Code is embedded; 
	(ii) to include a valid copyright notice on Your software product in which the Sample 
		Code is embedded; and 
	(iii) to indemnify, hold harmless, and defend Us and our suppliers from and against 
		any claims or lawsuits, including attorneys fees, that arise or result from the 
		use or distribution of the Sample Code.
*/
USE MemoryOptimizedDB
GO
DROP PROCEDURE IF EXISTS nsp_WorkOrder_Insert
DROP Procedure IF EXISTS rsp_WorkOrder
DROP Procedure IF EXISTS nat_WorkOrder
DROP Procedure IF EXISTS nat_WorkOrder_batch
DROP TABLE IF EXISTS WorkOrder
GO

CREATE TABLE [WorkOrder](
    [WorkOrderID] [int] IDENTITY (1, 1) NOT NULL PRIMARY KEY NONCLUSTERED,
    [ProductID] [int] NOT NULL,
    [OrderQty] [int] NOT NULL,
    [StockedQty] [int] NULL, -- AS ISNULL([OrderQty] - [ScrappedQty], 0),
    [ScrappedQty] [smallint] NOT NULL,
    [StartDate] [datetime] NOT NULL,
    [EndDate] [datetime] NULL,
    [DueDate] [datetime] NOT NULL,
    [ScrapReasonID] [smallint] NULL, 
    [ModifiedDate] [datetime] NOT NULL CONSTRAINT [DF_WorkOrder_ModifiedDate] DEFAULT (GETDATE()), 
) 	WITH (memory_optimized = on) ;
GO

--- Now lets create some procedures
-- INTEROP
DROP Procedure IF EXISTS rsp_WorkOrder
GO
Create Procedure rsp_WorkOrder
@ProductID INT = 9999,
@OrderQty INT = 100
as
Begin
	Insert into WorkOrder (
    [ProductID]  ,
    [OrderQty]  ,
    [StockedQty]  , 
    [ScrappedQty]  ,
    [StartDate]  ,
    [EndDate]  ,
    [DueDate]  ,
    [ScrapReasonID]  , 
    [ModifiedDate]   
	)
	values(
		@ProductID,
		@OrderQty,
		NULL,
		0,
		getdate(),
		NULL,
		dateadd(d,7,getdate()),
		NULL,
		getdate()
		)
end
go


-- Now test Regular Table
-- Proc that inserts 1 row at a time
set nocount on
declare @counter int = 1
declare @startdate datetime = getdate()
while @counter <= 10000
begin
	exec rsp_WorkOrder
	set @counter= @counter+1
end
select datediff(ms,@startdate,getdate()) as TimeinMilliseconds
go
-- check the entries on table
SELECT COUNT(*) FROM dbo.WorkOrder WHERE ProductID = 9999


-- Natively compiled SP: Chatty
DROP Procedure IF EXISTS nat_WorkOrder
GO
Create Procedure nat_WorkOrder
@ProductID INT = 8888,
@OrderQty INT = 100

  WITH 
    NATIVE_COMPILATION, 
    SCHEMABINDING, 
    EXECUTE AS OWNER
AS 
BEGIN ATOMIC 
  WITH 
(TRANSACTION  ISOLATION LEVEL = SNAPSHOT,
 LANGUAGE = 'us_english')
	Insert into dbo.WorkOrder (
    [ProductID]  ,
    [OrderQty]  ,
    [StockedQty]  , 
    [ScrappedQty]  ,
    [StartDate]  ,
    [EndDate]  ,
    [DueDate]  ,
    [ScrapReasonID]  , 
    [ModifiedDate]   
	)
	values(
		@ProductID,
		@OrderQty,
		NULL,
		0,
		getdate(),
		NULL,
		dateadd(d,7,getdate()),
		NULL,
		getdate()
		)
end
go

-- Test Native Proc with singleton insert
-- Natively compiled proc inserts 1 row at a time, invoked 10000 times.
-- Difference in perf exists but only about 40% better.
set nocount on
declare @counter int = 1
declare @startdate datetime = getdate()
while @counter <= 10000
begin
	exec dbo.nat_WorkOrder 8888,100
	set @counter= @counter+1
end
select datediff(ms,@startdate,getdate()) as TimeinMilliseconds
go
-- check the entries on table
SELECT COUNT(*) FROM dbo.WorkOrder WHERE ProductID = 8888

-- What if we move the Entire loop into the Native proc?
DROP Procedure IF EXISTS nat_WorkOrder_batch
GO
Create Procedure nat_WorkOrder_batch
@ProductID INT = 7777,
@OrderQty INT = 100,
@OrderNum int = 100

  WITH 
    NATIVE_COMPILATION, 
    SCHEMABINDING, 
    EXECUTE AS OWNER
AS 
BEGIN ATOMIC WITH 
	(TRANSACTION  ISOLATION LEVEL = SNAPSHOT,
	LANGUAGE = 'us_english')

	declare @counter int = 1
	while @counter <= @OrderNum
		begin
			Insert into dbo.WorkOrder (
			[ProductID]  ,
			[OrderQty]  ,
			[StockedQty]  , 
			[ScrappedQty]  ,
			[StartDate]  ,
			[EndDate]  ,
			[DueDate]  ,
			[ScrapReasonID]  , 
			[ModifiedDate]   
			)
			values(
				@ProductID,
				@OrderQty,
				NULL,
				0,
				getdate(),
				NULL,
				dateadd(d,7,getdate()),
				NULL,
				getdate()
				)
			set @counter= @counter+1
		end
END
go


-- Invoke the batch insert for Memory optimized table
-- SHould be a HUGE performance difference, bump up to 50000 records
declare @startdate datetime = getdate()
exec dbo.nat_WorkOrder_batch 7777,100,10000
select datediff(ms,@startdate,getdate()) as TimeinMilliseconds
go

SELECT COUNT(*) FROM dbo.WorkOrder WHERE ProductID = 7777


-- CLEAN UP
/*
DROP PROCEDURE IF EXISTS nsp_WorkOrder_Insert
DROP Procedure IF EXISTS rsp_WorkOrder
DROP Procedure IF EXISTS nat_WorkOrder
DROP Procedure IF EXISTS nat_WorkOrder_batch
DROP TABLE IF EXISTS WorkOrder
*/