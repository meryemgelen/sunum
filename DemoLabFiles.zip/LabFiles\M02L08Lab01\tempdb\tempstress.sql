SET NOCOUNT ON;
GO
EXEC letsgomavs;
GO