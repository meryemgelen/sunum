EXEC sys.sp_configure N'max server memory (MB)', N'2147483647'
GO
RECONFIGURE WITH OVERRIDE
GO
