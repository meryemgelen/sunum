Use AdventureWorksPTO
go
update NewSalesOrderHeader set Status = 5 where SalesOrderID = 43665
