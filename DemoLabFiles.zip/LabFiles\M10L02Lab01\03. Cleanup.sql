ALTER EVENT SESSION [CheckResourceUsage] ON SERVER  
STATE = stop;  
GO  
DROP EVENT SESSION [CheckResourceUsage] ON SERVER 
GO